import Stripe from "npm:stripe@14";
import { createClient } from "npm:@blinkdotnew/sdk";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "authorization, content-type",
};

async function handler(req: Request): Promise<Response> {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders });
  }

  try {
    const stripeKey = Deno.env.get("STRIPE_SECRET_KEY");
    if (!stripeKey) {
      return new Response(
        JSON.stringify({ error: "Stripe not configured" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const stripe = new Stripe(stripeKey, { apiVersion: "2024-06-20" });
    const body = await req.json();
    const { mode } = body;

    let lineItems: Stripe.Checkout.SessionCreateParams.LineItem[];
    let metadata: Record<string, string> = {};

    if (mode === "addon") {
      // ── Add-on service checkout ──────────────────────────────────────────
      const { serviceName, serviceDescription, amount, customerEmail, userId } = body;

      lineItems = [
        {
          price_data: {
            currency: "usd",
            product_data: {
              name: serviceName,
              description: serviceDescription ?? serviceName,
            },
            unit_amount: Math.round(amount * 100),
          },
          quantity: 1,
        },
      ];

      metadata = {
        mode: "addon",
        serviceName: serviceName ?? "",
        userId: userId ?? "",
        customerEmail: customerEmail ?? "",
      };

      const session = await stripe.checkout.sessions.create({
        mode: "payment",
        payment_method_types: ["card"],
        line_items: lineItems,
        customer_email: customerEmail || undefined,
        allow_promotion_codes: true,
        metadata,
        success_url: body.successUrl + "?session_id={CHECKOUT_SESSION_ID}",
        cancel_url: body.cancelUrl,
      });

      return new Response(
        JSON.stringify({ url: session.url, sessionId: session.id }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );

    } else {
      // ── Company formation checkout (original flow) ───────────────────────
      const {
        planName,
        amount,
        companyName,
        companyState,
        companyType,
        businessActivity,
        customerEmail,
        customerName,
        customerPhone,
        customerCountry,
        customerAddress,
        userId,
        successUrl,
        cancelUrl,
      } = body;

      lineItems = [
        {
          price_data: {
            currency: "usd",
            product_data: {
              name: planName,
              description: `${companyType} formation · ${companyState} · ${businessActivity}`,
              metadata: {
                companyName,
                companyState,
                companyType,
                businessActivity,
              },
            },
            unit_amount: Math.round(amount * 100),
          },
          quantity: 1,
        },
      ];

      metadata = {
        mode: "formation",
        plan: planName ?? "",
        companyName: companyName ?? "",
        companyState: companyState ?? "",
        companyType: companyType ?? "",
        businessActivity: businessActivity ?? "",
        customerName: customerName ?? "",
        customerEmail: customerEmail ?? "",
        customerPhone: customerPhone ?? "",
        customerCountry: customerCountry ?? "",
        customerAddress: customerAddress ?? "",
        userId: userId ?? "",
      };

      const session = await stripe.checkout.sessions.create({
        mode: "payment",
        payment_method_types: ["card"],
        line_items: lineItems,
        customer_email: customerEmail,
        allow_promotion_codes: true,
        metadata,
        success_url: successUrl + "?session_id={CHECKOUT_SESSION_ID}",
        cancel_url: cancelUrl,
      });

      return new Response(
        JSON.stringify({ url: session.url, sessionId: session.id }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

  } catch (err) {
    console.error("Checkout error:", err);
    return new Response(
      JSON.stringify({ error: err instanceof Error ? err.message : "Internal error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
}

Deno.serve(handler);
