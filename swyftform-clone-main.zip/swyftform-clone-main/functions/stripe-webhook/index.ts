import Stripe from "npm:stripe@14";
import { createClient } from "npm:@supabase/supabase-js@2";

function getCorsOrigin(req: Request): string {
  const allowed = Deno.env.get("ALLOWED_ORIGIN") || "";
  const origin = req.headers.get("origin") || "";
  return allowed && origin === allowed ? origin : "";
}

function corsHeaders(req: Request) {
  return {
    "Access-Control-Allow-Origin": getCorsOrigin(req),
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers": "authorization, content-type, stripe-signature",
    "Vary": "Origin",
  };
}

async function handler(req: Request): Promise<Response> {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders(req) });
  }

  const stripeKey = Deno.env.get("STRIPE_SECRET_KEY");
  const webhookSecret = Deno.env.get("STRIPE_WEBHOOK_SECRET");
  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

  if (!stripeKey || !webhookSecret || !supabaseUrl || !supabaseServiceKey) {
    console.error("Missing env vars");
    return new Response(JSON.stringify({ error: "Missing config" }), {
      status: 500,
      headers: { ...corsHeaders(req), "Content-Type": "application/json" },
    });
  }

  const stripe = new Stripe(stripeKey, { apiVersion: "2024-06-20" });
  const supabase = createClient(supabaseUrl, supabaseServiceKey);

  // Verify Stripe signature
  const sig = req.headers.get("stripe-signature");
  const body = await req.text();

  let event: Stripe.Event;
  try {
    event = await stripe.webhooks.constructEventAsync(body, sig!, webhookSecret);
  } catch (err) {
    console.error("Webhook signature verification failed:", err);
    return new Response(JSON.stringify({ error: "Invalid signature" }), {
      status: 400,
      headers: { ...corsHeaders(req), "Content-Type": "application/json" },
    });
  }

  if (event.type === "checkout.session.completed") {
    const session = event.data.object as Stripe.Checkout.Session;
    const meta = session.metadata ?? {};
    const now = new Date().toISOString();
    const isAddon = meta.mode === "addon";

    try {
      // Idempotency: skip if this Stripe session was already processed
      const { data: existing } = await supabase
        .from("orders")
        .select("id")
        .eq("stripe_session_id", session.id)
        .maybeSingle();
      if (existing) {
        console.log(`⏭️ Session ${session.id} already processed, skipping`);
        return new Response(JSON.stringify({ received: true, duplicate: true }), {
          status: 200,
          headers: { ...corsHeaders(req), "Content-Type": "application/json" },
        });
      }

      const userId = meta.userId || null;

      if (isAddon) {
        // ── Add-on service payment ─────────────────────────────────────────
        const invoiceId = `INV-${crypto.randomUUID().replace(/-/g, "").slice(0, 16).toUpperCase()}`;
        const orderId = crypto.randomUUID();
        const orderNumber = `SVC-${crypto.randomUUID().replace(/-/g, "").slice(0, 16).toUpperCase()}`;

        // Create order first (payments.order_id is a FK to orders.id)
        const { error: ordErr } = await supabase.from("orders").insert({
          id: orderId,
          user_id: userId,
          order_number: orderNumber,
          package_name: meta.serviceName ?? "Add-on Service",
          company_name: "",
          company_state: "",
          company_type: "LLC",
          status: "in_progress",
          amount: (session.amount_total ?? 0) / 100,
          currency: session.currency?.toUpperCase() ?? "USD",
          customer_email: meta.customerEmail || null,
          stripe_session_id: session.id,
          notes: "Add-on service purchase.",
        });
        if (ordErr) throw new Error(`Order insert failed: ${ordErr.message}`);

        // Record payment (after order exists)
        const { error: payErr } = await supabase.from("payments").insert({
          user_id: userId,
          order_id: orderId,
          invoice_id: invoiceId,
          service: meta.serviceName ?? "Add-on Service",
          amount: (session.amount_total ?? 0) / 100,
          currency: session.currency?.toUpperCase() ?? "USD",
          status: "paid",
          stripe_payment_id: session.id,
        });
        if (payErr) console.error("Payment insert failed:", payErr);

        // Log order update
        const { error: updateErr } = await supabase.from("order_updates").insert({
          order_id: orderId,
          status: "in_progress",
          message: `Payment received for "${meta.serviceName}". Our team will begin processing shortly.`,
          created_by: "system",
        });
        if (updateErr) console.error("Order update insert failed:", updateErr);

        console.log(`✅ Add-on service paid: ${meta.serviceName} by ${meta.customerEmail}`);

      } else {
        // ── Company formation payment ──────────────────────────────────────
        const orderId = crypto.randomUUID();
        const orderNumber = `IG-${crypto.randomUUID().replace(/-/g, "").slice(0, 16).toUpperCase()}`;
        const invoiceId = `INV-${crypto.randomUUID().replace(/-/g, "").slice(0, 16).toUpperCase()}`;

        // Create order
        const { error: ordErr } = await supabase.from("orders").insert({
          id: orderId,
          user_id: userId,
          order_number: orderNumber,
          package_name: meta.plan ?? "Unknown Plan",
          company_name: meta.companyName ?? "Unknown",
          company_state: meta.companyState ?? "",
          company_type: meta.companyType ?? "LLC",
          status: "pending",
          amount: (session.amount_total ?? 0) / 100,
          currency: session.currency?.toUpperCase() ?? "USD",
          customer_name: meta.customerName || null,
          customer_email: meta.customerEmail || null,
          customer_phone: meta.customerPhone || null,
          customer_country: meta.customerCountry || null,
          customer_address: meta.customerAddress || null,
          business_activity: meta.businessActivity || null,
          stripe_session_id: session.id,
        });
        if (ordErr) throw new Error(`Order insert failed: ${ordErr.message}`);

        // Record payment
        const { error: payErr } = await supabase.from("payments").insert({
          user_id: userId,
          order_id: orderId,
          invoice_id: invoiceId,
          service: meta.plan ?? "Formation",
          amount: (session.amount_total ?? 0) / 100,
          currency: session.currency?.toUpperCase() ?? "USD",
          status: "paid",
          stripe_payment_id: session.id,
        });
        if (payErr) console.error("Payment insert failed:", payErr);

        // Create pending company record
        const { error: compErr } = await supabase.from("companies").insert({
          user_id: userId,
          order_id: orderId,
          company_name: meta.companyName ?? "Unknown",
          company_type: meta.companyType ?? "LLC",
          state: meta.companyState ?? "",
          status: "pending",
        });
        if (compErr) console.error("Company insert failed:", compErr);

        // Log update
        const { error: updateErr } = await supabase.from("order_updates").insert({
          order_id: orderId,
          status: "pending",
          message: `Order created after successful payment. Stripe session: ${session.id}`,
          created_by: "system",
        });
        if (updateErr) console.error("Order update insert failed:", updateErr);

        console.log(`✅ Formation order ${orderNumber} created for ${meta.companyName}`);
      }
    } catch (dbErr) {
      console.error("DB write failed:", dbErr);
      return new Response(JSON.stringify({ error: "Database write failed" }), {
        status: 500,
        headers: { ...corsHeaders(req), "Content-Type": "application/json" },
      });
    }
  }

  return new Response(JSON.stringify({ received: true }), {
    status: 200,
    headers: { ...corsHeaders(req), "Content-Type": "application/json" },
  });
}

Deno.serve(handler);
