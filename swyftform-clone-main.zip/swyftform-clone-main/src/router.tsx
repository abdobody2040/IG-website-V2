import {
  createRouter,
  createRoute,
  createRootRoute,
  Outlet,
  redirect,
} from '@tanstack/react-router'
import { LanguageProvider } from './i18n/LanguageContext'
import Navbar from './components/Navbar'
import Hero from './components/Hero'
import HowItWorks from './components/HowItWorks'
import Features from './components/Features'
import Pricing from './components/Pricing'
import Reviews from './components/Reviews'
import FAQ from './components/FAQ'
import CTASection from './components/CTASection'
import Footer from './components/Footer'
import LoginPage from './pages/auth/LoginPage'
import SignupPage from './pages/auth/SignupPage'
import AuthCallbackPage from './pages/auth/AuthCallbackPage'

// Client pages
import ClientDashboardPage from './pages/client/ClientDashboardPage'
import ClientOrdersPage from './pages/client/ClientOrdersPage'
import ClientCompanyPage from './pages/client/ClientCompanyPage'
import ClientDocumentsPage from './pages/client/ClientDocumentsPage'
import ClientServicesPage from './pages/client/ClientServicesPage'
import ClientPaymentsPage from './pages/client/ClientPaymentsPage'
import ClientMailInboxPage from './pages/client/ClientMailInboxPage'
import ClientVerificationsPage from './pages/client/ClientVerificationsPage'

// Order pages
import OrderWizard from './pages/order/OrderWizard'
import OrderSuccess from './pages/order/OrderSuccess'

// Admin pages
import AdminDashboardPage from './pages/admin/AdminDashboardPage'
import AdminOverviewPage from './pages/admin/AdminOverviewPage'
import AdminOrdersPage from './pages/admin/AdminOrdersPage'
import AdminClientsPage from './pages/admin/AdminClientsPage'
import AdminAnalyticsPage from './pages/admin/AdminAnalyticsPage'
import AdminSettingsPage from './pages/admin/AdminSettingsPage'
import AdminCompaniesPage from './pages/admin/AdminCompaniesPage'
import AdminDocumentsPage from './pages/admin/AdminDocumentsPage'
import AdminPaymentsPage from './pages/admin/AdminPaymentsPage'
import AdminClientDetailPage from './pages/admin/AdminClientDetailPage'
import ContactPage from './pages/ContactPage'
import ClientSettingsPage from './pages/client/ClientSettingsPage'
import SetupPage from './pages/SetupPage'

// Root route — LanguageProvider wraps everything so i18n is available to all pages
const rootRoute = createRootRoute({
  component: () => (
    <LanguageProvider>
      <Outlet />
    </LanguageProvider>
  ),
})

// ── Landing page (/） ──────────────────────────────────────────────────────
const landingRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/',
  component: () => (
      <div className="min-h-screen bg-white font-sans">
        <Navbar />
        <main>
          <Hero />
          <HowItWorks />
          <Features />
          <Pricing />
          <Reviews />
          <FAQ />
          <CTASection />
        </main>
        <Footer />
      </div>
  ),
})

// ── Auth routes ────────────────────────────────────────────────────────────
const loginRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/auth/login',
  component: LoginPage,
})

const signupRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/auth/signup',
  component: SignupPage,
})

const authCallbackRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/auth/callback',
  component: AuthCallbackPage,
})

// ── Order routes ───────────────────────────────────────────────────────────
const orderRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/order',
  component: OrderWizard,
})

const orderSuccessRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/order/success',
  component: OrderSuccess,
})

// ── Client portal routes ───────────────────────────────────────────────────
const dashboardRedirectRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/client/dashboard',
  component: ClientDashboardPage,
})

const clientOrdersRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/client/orders',
  component: ClientOrdersPage,
})

const clientCompanyRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/client/company',
  component: ClientCompanyPage,
})

const clientDocumentsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/client/documents',
  component: ClientDocumentsPage,
})

const clientServicesRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/client/services',
  component: ClientServicesPage,
})

// ── Admin routes ───────────────────────────────────────────────────────────
const adminRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/admin',
  component: AdminOverviewPage,
})

const adminDashboardRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/admin/dashboard',
  component: AdminDashboardPage,
})

const adminOrdersRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/admin/orders',
  component: AdminOrdersPage,
})

const adminClientsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/admin/clients',
  component: AdminClientsPage,
})

const adminAnalyticsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/admin/analytics',
  component: AdminAnalyticsPage,
})

const adminSettingsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/admin/settings',
  component: AdminSettingsPage,
})

const adminCompaniesRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/admin/companies',
  component: AdminCompaniesPage,
})

const adminDocumentsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/admin/documents',
  component: AdminDocumentsPage,
})

const adminPaymentsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/admin/payments',
  component: AdminPaymentsPage,
})

const adminClientDetailRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/admin/clients/$userId',
  component: AdminClientDetailPage,
})

const clientPaymentsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/client/payments',
  component: ClientPaymentsPage,
})

const clientMailInboxRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/client/mail-inbox',
  component: ClientMailInboxPage,
})

const clientVerificationsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/client/verifications',
  component: ClientVerificationsPage,
})

const contactRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/contact',
  component: () => (
    <LanguageProvider>
      <ContactPage />
    </LanguageProvider>
  ),
})

const clientSettingsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/client/settings',
  component: ClientSettingsPage,
})

const setupRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/setup',
  component: SetupPage,
})

// ── Route tree ─────────────────────────────────────────────────────────────
const routeTree = rootRoute.addChildren([
  landingRoute,
  loginRoute,
  signupRoute,
  authCallbackRoute,
  // Order
  orderRoute,
  orderSuccessRoute,
  // Client
  dashboardRedirectRoute,
  clientOrdersRoute,
  clientCompanyRoute,
  clientDocumentsRoute,
  clientServicesRoute,
  // Admin
  adminRoute,
  adminDashboardRoute,
  adminOrdersRoute,
  adminClientsRoute,
  adminAnalyticsRoute,
  adminSettingsRoute,
  adminCompaniesRoute,
  adminDocumentsRoute,
  adminPaymentsRoute,
  adminClientDetailRoute,
  contactRoute,
  clientSettingsRoute,
  clientPaymentsRoute,
  clientMailInboxRoute,
  clientVerificationsRoute,
  setupRoute,
])

export const router = createRouter({ routeTree })

// Register router for type safety
declare module '@tanstack/react-router' {
  interface Register {
    router: typeof router
  }
}

// suppress unused import warning
void redirect