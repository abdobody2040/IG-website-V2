export interface Order {
  id: string
  userId: string
  orderNumber: string
  packageName: string
  companyName: string
  companyState: string
  companyType: string  // 'LLC' | 'LTD'
  status: string  // 'pending' | 'in_review' | 'processing' | 'documents_filed' | 'ein_processing' | 'completed' | 'cancelled' | 'in_progress'
  amount: number
  currency: string
  notes: string
  customerName: string | null
  customerEmail: string | null
  customerPhone: string | null
  customerCountry: string | null
  customerAddress: string | null
  businessActivity: string | null
  stripeSessionId: string | null
  createdAt: string
  updatedAt: string
}

export interface Company {
  id: string
  userId: string
  orderId: string
  companyName: string
  companyType: string
  state: string
  einNumber: string
  formationDate: string
  registeredAgent: string
  status: string
  createdAt: string
  updatedAt: string
}

export interface Document {
  id: string
  userId: string
  orderId: string
  companyId: string
  name: string
  docType: string  // 'articles_of_org' | 'operating_agreement' | 'ein_letter' | 'banking_resolution' | 'other'
  fileUrl: string
  fileName: string
  status: string  // 'pending' | 'ready' | 'uploaded' | 'approved' | 'rejected'
  notes: string
  createdAt: string
  updatedAt: string
}

export interface OrderUpdate {
  id: string
  orderId: string
  status: string
  message: string
  createdBy: string
  createdAt: string
}

export interface Payment {
  id: string
  userId: string
  orderId: string
  service: string
  invoiceId: string
  amount: number
  currency: string
  status: string  // 'pending' | 'paid' | 'failed' | 'refunded'
  stripePaymentId: string
  notes: string
  createdAt: string
  updatedAt: string
}

export interface User {
  id: string
  email: string
  emailVerified: boolean
  displayName: string
  avatarUrl: string
  phone: string
  phoneVerified: boolean
  role: string
  country: string
  address: string
  metadata: string
  createdAt: string
  updatedAt: string
  lastSignIn: string
}
