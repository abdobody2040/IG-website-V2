import { useQuery } from '@tanstack/react-query'
import { supabase } from '../lib/supabase'
import type { Document } from '../types/db'

export function useDocuments(userId: string | undefined | null) {
  const { data, isLoading, error } = useQuery({
    queryKey: ['documents', userId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('documents')
        .select('*')
        .eq('user_id', userId!)
        .order('created_at', { ascending: false })
      if (error) throw error
      return (data ?? []).map(mapDocument)
    },
    enabled: !!userId,
  })

  return {
    documents: data ?? [],
    isLoading,
    error,
  }
}

function mapDocument(row: Record<string, unknown>): Document {
  return {
    id: row.id as string,
    userId: row.user_id as string,
    orderId: row.order_id as string,
    companyId: row.company_id as string,
    name: row.name as string,
    docType: row.doc_type as string,
    fileUrl: (row.file_url as string) ?? '',
    fileName: (row.file_name as string) ?? '',
    status: row.status as string,
    notes: (row.notes as string) ?? '',
    createdAt: row.created_at as string,
    updatedAt: row.updated_at as string,
  }
}
