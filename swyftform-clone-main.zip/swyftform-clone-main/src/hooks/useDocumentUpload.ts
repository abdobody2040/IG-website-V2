import { useState, useCallback } from 'react'
import { useQueryClient } from '@tanstack/react-query'
import { supabase } from '../lib/supabase'

interface UploadOptions {
  userId: string
  orderId?: string
  companyId?: string
}

interface UploadState {
  uploading: boolean
  progress: number
  error: string | null
}

const R2_UPLOAD_ENDPOINT = import.meta.env.VITE_R2_UPLOAD_ENDPOINT as string | undefined

const MAX_FILE_SIZE = 10 * 1024 * 1024 // 10 MB
const ALLOWED_TYPES = [
  'application/pdf',
  'image/png',
  'image/jpeg',
  'image/webp',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
]

export function useDocumentUpload({ userId, orderId = '', companyId = '' }: UploadOptions) {
  const queryClient = useQueryClient()
  const [state, setState] = useState<UploadState>({
    uploading: false,
    progress: 0,
    error: null,
  })

  const upload = useCallback(async (file: File, docType: string = 'other'): Promise<boolean> => {
    setState({ uploading: true, progress: 0, error: null })

    try {
      if (file.size > MAX_FILE_SIZE) {
        throw new Error('File too large. Maximum size is 10 MB.')
      }
      if (ALLOWED_TYPES.length > 0 && !ALLOWED_TYPES.includes(file.type)) {
        throw new Error('File type not allowed. Accepted: PDF, PNG, JPEG, WEBP, DOC, DOCX.')
      }

      const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, '_')
      const path = `user-docs/${userId}/${Date.now()}-${safeName}`
      let publicUrl: string

      if (R2_UPLOAD_ENDPOINT) {
        // Upload to Cloudflare R2 via server proxy
        const { data: { session } } = await supabase.auth.getSession()
        const formData = new FormData()
        formData.append('file', file)
        formData.append('path', path)

        const res = await fetch(R2_UPLOAD_ENDPOINT, {
          method: 'POST',
          headers: session?.access_token
            ? { Authorization: `Bearer ${session.access_token}` }
            : {},
          body: formData,
        })
        if (!res.ok) throw new Error('Upload to R2 failed')
        const json = await res.json()
        publicUrl = json.url
      } else {
        // Fallback: upload to Supabase Storage
        const { error: uploadError } = await supabase.storage
          .from('documents')
          .upload(path, file, { upsert: true })
        if (uploadError) throw uploadError
        const { data: urlData } = supabase.storage
          .from('documents')
          .getPublicUrl(path)
        publicUrl = urlData.publicUrl
      }

      setState(s => ({ ...s, progress: 80 }))

      // Save document record to DB
      const { error: dbError } = await supabase.from('documents').insert({
        user_id: userId,
        order_id: orderId || null,
        company_id: companyId || null,
        name: file.name,
        doc_type: docType,
        file_url: publicUrl,
        file_name: safeName,
        status: 'ready',
      })
      if (dbError) throw dbError

      // Invalidate document cache
      await queryClient.invalidateQueries({ queryKey: ['documents', userId] })

      setState({ uploading: false, progress: 100, error: null })
      return true
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Upload failed. Please try again.'
      setState({ uploading: false, progress: 0, error: msg })
      return false
    }
  }, [userId, orderId, companyId, queryClient])

  const reset = useCallback(() => {
    setState({ uploading: false, progress: 0, error: null })
  }, [])

  return { ...state, upload, reset }
}
