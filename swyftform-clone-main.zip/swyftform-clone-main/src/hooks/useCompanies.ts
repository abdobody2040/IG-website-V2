import { useQuery } from '@tanstack/react-query'
import { supabase } from '../lib/supabase'
import type { Company } from '../types/db'

export function useCompanies(userId: string | undefined | null) {
  const { data, isLoading, error } = useQuery({
    queryKey: ['companies', userId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('companies')
        .select('*')
        .eq('user_id', userId!)
        .order('created_at', { ascending: false })
      if (error) throw error
      return (data ?? []).map(mapCompany)
    },
    enabled: !!userId,
  })

  return {
    companies: data ?? [],
    isLoading,
    error,
  }
}

function mapCompany(row: Record<string, unknown>): Company {
  return {
    id: row.id as string,
    userId: row.user_id as string,
    orderId: row.order_id as string,
    companyName: row.company_name as string,
    companyType: row.company_type as string,
    state: row.state as string,
    einNumber: row.ein_number as string,
    formationDate: row.formation_date as string,
    registeredAgent: row.registered_agent as string,
    status: row.status as string,
    createdAt: row.created_at as string,
    updatedAt: row.updated_at as string,
  }
}
