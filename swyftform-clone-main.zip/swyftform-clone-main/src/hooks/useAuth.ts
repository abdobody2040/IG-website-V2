import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'
import type { User as SupabaseUser } from '@supabase/supabase-js'

export interface AppUser {
  id: string
  email?: string
  displayName?: string
  avatarUrl?: string
  role?: string
  phone?: string
}

interface AuthState {
  user: AppUser | null
  isLoading: boolean
  isAuthenticated: boolean
}

function mapUser(su: SupabaseUser): AppUser {
  return {
    id: su.id,
    email: su.email,
    displayName: su.user_metadata?.full_name ?? su.user_metadata?.name ?? su.email?.split('@')[0],
    avatarUrl: su.user_metadata?.avatar_url,
  }
}

export function useAuth(): AuthState {
  const [user, setUser] = useState<AppUser | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Get initial session
    supabase.auth.getSession().then(async ({ data: { session } }) => {
      if (session?.user) {
        const appUser = mapUser(session.user)
        // Fetch role from profiles table
        const { data: profile } = await supabase
          .from('profiles')
          .select('role, display_name, phone, avatar_url')
          .eq('id', session.user.id)
          .single()
        if (profile) {
          appUser.role = profile.role ?? 'client'
          appUser.displayName = profile.display_name ?? appUser.displayName
          appUser.phone = profile.phone ?? undefined
          appUser.avatarUrl = profile.avatar_url ?? appUser.avatarUrl
        }
        setUser(appUser)
      }
      setIsLoading(false)
    })

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        if (session?.user) {
          const appUser = mapUser(session.user)
          const { data: profile } = await supabase
            .from('profiles')
            .select('role, display_name, phone, avatar_url')
            .eq('id', session.user.id)
            .single()
          if (profile) {
            appUser.role = profile.role ?? 'client'
            appUser.displayName = profile.display_name ?? appUser.displayName
            appUser.phone = profile.phone ?? undefined
            appUser.avatarUrl = profile.avatar_url ?? appUser.avatarUrl
          }
          // Update last_sign_in on login (uses RPC to bypass column-level trigger)
          if (event === 'SIGNED_IN') {
            supabase.rpc('update_last_sign_in').then(() => {})
          }
          setUser(appUser)
        } else {
          setUser(null)
        }
        setIsLoading(false)
      }
    )

    return () => subscription.unsubscribe()
  }, [])

  return {
    user,
    isLoading,
    isAuthenticated: !!user,
  }
}
