import { useState } from 'react'
import { Menu, X, Globe } from 'lucide-react'
import { useLang } from '../i18n/LanguageContext'

export default function Navbar() {
  const [mobileOpen, setMobileOpen] = useState(false)
  const { t, lang, toggleLang } = useLang()
  const n = t.nav

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white border-b border-gray-100 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <a href="/" className="flex items-center gap-2">
            <img src="/logo.png" alt="Instant Grow" className="h-10 w-auto" />
          </a>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-8">
            <a href="/#features" className="text-sm font-medium text-gray-600 hover:text-[#1a56ff] transition-colors">{n.features}</a>
            <a href="/#pricing" className="text-sm font-medium text-gray-600 hover:text-[#1a56ff] transition-colors">{n.pricing}</a>
            <a href="/#faq" className="text-sm font-medium text-gray-600 hover:text-[#1a56ff] transition-colors">{n.faq}</a>
            <a href="/contact" className="text-sm font-medium text-gray-600 hover:text-[#1a56ff] transition-colors">{n.contact}</a>
          </nav>

          {/* Desktop Actions */}
          <div className="hidden md:flex items-center gap-3">
            {/* Language Toggle */}
            <button
              onClick={toggleLang}
              className="flex items-center gap-1.5 text-sm font-semibold text-gray-500 hover:text-[#1a56ff] transition-colors px-3 py-1.5 rounded-lg hover:bg-gray-50 border border-gray-200 hover:border-[#1a56ff]/30"
            >
              <Globe size={15} />
              <span>{lang === 'en' ? 'العربية' : 'English'}</span>
            </button>
            <a href="/auth/login" className="text-sm font-medium text-[#0a0f1e] hover:text-[#1a56ff] transition-colors px-3 py-2 border border-gray-200 rounded-lg hover:border-[#1a56ff]/30">{n.login}</a>
            <a
              href="/order"
              className="bg-[#1a56ff] text-white text-sm font-semibold px-5 py-2.5 rounded-lg hover:bg-[#3a76ff] transition-colors shadow-sm"
            >
              {n.cta}
            </a>
          </div>

          {/* Mobile menu toggle */}
          <button
            className="md:hidden text-gray-600 hover:text-[#1a56ff]"
            onClick={() => setMobileOpen(!mobileOpen)}
          >
            {mobileOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="md:hidden bg-white border-t border-gray-100 px-4 py-4 space-y-3">
          <a href="/#features" className="block text-sm font-medium text-gray-600 py-2" onClick={() => setMobileOpen(false)}>{n.features}</a>
          <a href="/#pricing" className="block text-sm font-medium text-gray-600 py-2" onClick={() => setMobileOpen(false)}>{n.pricing}</a>
          <a href="/#faq" className="block text-sm font-medium text-gray-600 py-2" onClick={() => setMobileOpen(false)}>{n.faq}</a>
          <a href="/contact" className="block text-sm font-medium text-gray-600 py-2" onClick={() => setMobileOpen(false)}>{n.contact}</a>
          <div className="flex flex-col gap-2 pt-2 border-t border-gray-100">
            <button
              onClick={() => { toggleLang(); setMobileOpen(false) }}
              className="flex items-center gap-2 text-sm font-semibold text-gray-600 py-2"
            >
              <Globe size={15} />
              {lang === 'en' ? 'العربية' : 'English'}
            </button>
            <a href="/auth/login" className="text-sm font-medium text-[#0a0f1e] py-2">{n.login}</a>
            <a href="/order" className="bg-[#1a56ff] text-white text-sm font-semibold px-5 py-3 rounded-lg text-center hover:bg-[#3a76ff] transition-colors">
              {n.cta}
            </a>
          </div>
        </div>
      )}
    </header>
  )
}
