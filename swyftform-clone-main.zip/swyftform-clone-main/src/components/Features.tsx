import { Zap, Shield, FileText, ClipboardList, Bell, HeadphonesIcon } from 'lucide-react'
import { useLang } from '../i18n/LanguageContext'

const icons = [Zap, Shield, FileText, ClipboardList, Bell, HeadphonesIcon]

export default function Features() {
  const { t } = useLang()
  const f = t.features

  return (
    <section id="features" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <div className="text-center mb-4">
          <p className="text-[#1a56ff] text-sm font-semibold uppercase tracking-wider">{f.label}</p>
        </div>
        <h2
          className="text-3xl sm:text-4xl font-bold text-[#0a0f1e] text-center mb-4"
          style={{ fontFamily: 'Sora, Inter, sans-serif' }}
        >
          {f.heading}
        </h2>
        <p className="text-gray-500 text-center max-w-2xl mx-auto mb-16">
          {f.subheading}
        </p>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {f.items.map((feature, index) => {
            const Icon = icons[index]
            return (
              <div
                key={index}
                className="group p-6 rounded-2xl border border-gray-100 bg-white hover:border-[#1a56ff]/30 hover:shadow-lg hover:shadow-blue-50 transition-all duration-300"
              >
                <div className="w-12 h-12 bg-[#1a56ff]/10 rounded-xl flex items-center justify-center mb-4 group-hover:bg-[#1a56ff]/20 transition-colors">
                  <Icon size={22} className="text-[#1a56ff]" />
                </div>
                <h3 className="text-lg font-semibold text-[#0a0f1e] mb-2" style={{ fontFamily: 'Sora, Inter, sans-serif' }}>{feature.title}</h3>
                <p className="text-gray-500 text-sm leading-relaxed">{feature.description}</p>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
