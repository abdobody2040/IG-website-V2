import { Star, ArrowRight } from 'lucide-react'
import { useLang } from '../i18n/LanguageContext'

export default function Hero() {
  const { t } = useLang()
  const h = t.hero

  return (
    <section className="pt-24 pb-16 bg-gradient-to-b from-[#0a0f1e] to-[#111827] text-white overflow-hidden relative">
      {/* Subtle grid overlay */}
      <div
        className="absolute inset-0 opacity-[0.04] pointer-events-none"
        style={{
          backgroundImage: 'linear-gradient(rgba(255,255,255,0.6) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.6) 1px, transparent 1px)',
          backgroundSize: '48px 48px',
        }}
      />
      {/* Radial blue glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[500px] bg-[#1a56ff]/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Trustpilot badge */}
        <div className="flex justify-center mb-6">
          <a
            href="https://www.trustpilot.com/review/instantgrow.net"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 bg-white/10 border border-white/20 rounded-full px-4 py-1.5 text-sm font-medium text-white hover:bg-white/15 transition-colors"
          >
            <div className="flex gap-0.5">
              {[...Array(5)].map((_, i) => (
                <Star key={i} size={12} className="fill-[#00B67A] text-[#00B67A]" />
              ))}
            </div>
            <span className="font-semibold">5.0</span>
            <span className="text-white/70">{h.trustpilot}</span>
          </a>
        </div>

        {/* Headline */}
        <div className="text-center max-w-4xl mx-auto mb-8">
          <h1
            className="text-4xl sm:text-5xl lg:text-6xl font-bold leading-tight mb-6"
            style={{ fontFamily: 'Sora, Inter, sans-serif' }}
          >
            {h.headline1}{' '}
            <span className="text-[#00d4ff]">{h.headline2}</span>
            <br />
            {h.headline3}
          </h1>
          <p className="text-lg sm:text-xl text-white/75 max-w-2xl mx-auto leading-relaxed">
            {h.subheadline}
          </p>
        </div>

        {/* CTA */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16">
          <a
            href="/order?plan=us-premium"
            className="w-full sm:w-auto bg-[#1a56ff] text-white font-bold text-base px-8 py-4 rounded-lg hover:bg-[#3a76ff] transition-all hover:shadow-xl hover:shadow-blue-500/25 hover:-translate-y-0.5 flex items-center justify-center gap-2"
          >
            {h.ctaPrimary}
            <ArrowRight size={18} />
          </a>
          <a
            href="#pricing"
            className="w-full sm:w-auto border border-white/20 text-white font-semibold text-base px-8 py-4 rounded-lg hover:bg-white/10 transition-all flex items-center justify-center gap-2"
          >
            {h.ctaSecondary}
          </a>
        </div>

        {/* Trust indicators */}
        <div className="flex flex-wrap items-center justify-center gap-6 mb-16 text-white/50 text-sm">
          <span className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-[#16a34a]" />
            {h.badge1}
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-[#16a34a]" />
            {h.badge2}
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-[#16a34a]" />
            {h.badge3}
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-[#16a34a]" />
            {h.badge4}
          </span>
        </div>

        {/* Hero dashboard mockup */}
        <div className="relative max-w-5xl mx-auto">
          <div className="absolute inset-0 bg-gradient-to-t from-[#111827] via-transparent to-transparent z-10 pointer-events-none" />
          <div className="rounded-2xl overflow-hidden shadow-2xl border border-white/10 bg-[#111827]">
            {/* Dashboard mockup */}
            <div className="bg-[#0a0f1e] border-b border-white/10 px-4 py-3 flex items-center gap-3">
              <div className="flex gap-1.5">
                <div className="w-3 h-3 rounded-full bg-red-500/60" />
                <div className="w-3 h-3 rounded-full bg-yellow-500/60" />
                <div className="w-3 h-3 rounded-full bg-green-500/60" />
              </div>
              <div className="flex-1 bg-white/5 rounded-md h-6 max-w-xs mx-auto flex items-center justify-center">
                <span className="text-white/30 text-xs">instantgrow.net/dashboard</span>
              </div>
            </div>
            <div className="bg-[#111827] p-6 min-h-[280px] flex gap-4">
              {/* Sidebar */}
              <div className="w-40 flex-shrink-0 space-y-1">
                <div className="flex items-center gap-2 px-3 py-2 bg-[#1a56ff] rounded-lg">
                  <div className="w-4 h-4 bg-white/30 rounded" />
                  <div className="h-2 bg-white/80 rounded w-16" />
                </div>
                {['Payments', 'My Company', 'Documents', 'Mail', 'Services'].map((item) => (
                  <div key={item} className="flex items-center gap-2 px-3 py-2 rounded-lg">
                    <div className="w-4 h-4 bg-white/10 rounded" />
                    <div className="h-2 bg-white/20 rounded w-14" />
                  </div>
                ))}
              </div>
              {/* Main content */}
              <div className="flex-1 space-y-4">
                <div className="grid grid-cols-3 gap-3">
                  {['Formation Progress', 'Company Status', 'EIN Number'].map((label) => (
                    <div key={label} className="bg-white/5 rounded-xl p-4 border border-white/10">
                      <div className="h-2 bg-white/20 rounded w-24 mb-3" />
                      <div className="h-6 bg-[#1a56ff]/40 rounded w-16" />
                    </div>
                  ))}
                </div>
                <div className="bg-white/5 rounded-xl p-4 border border-white/10">
                  <div className="h-2 bg-white/20 rounded w-32 mb-3" />
                  <div className="space-y-2">
                    {[75, 55, 90].map((w) => (
                      <div key={w} className="h-2 bg-white/10 rounded" style={{ width: `${w}%` }} />
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
