import { Mail } from 'lucide-react'
import { useLang } from '../i18n/LanguageContext'

export default function Footer() {
  const { t } = useLang()
  const f = t.footer

  return (
    <footer className="bg-[#0a0f1e] text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10 mb-12">
          {/* Brand */}
          <div className="md:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded-lg bg-[#1a56ff] flex items-center justify-center">
                <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
                  <path d="M3 5h12M3 9h8M3 13h10" stroke="white" strokeWidth="2" strokeLinecap="round"/>
                </svg>
              </div>
              <span className="text-xl font-bold" style={{ fontFamily: 'Sora, Inter, sans-serif' }}>Instant Grow</span>
            </div>
            <p className="text-white/50 text-sm leading-relaxed mb-5">
              {f.tagline}
            </p>
            <div className="flex items-center gap-3">
              <a
                href="mailto:info@instantgrow.net"
                className="w-9 h-9 bg-white/10 rounded-full flex items-center justify-center hover:bg-[#1a56ff]/30 transition-colors"
                title="Email us"
              >
                <Mail size={16} className="text-white/70" />
              </a>
              <a
                href="https://www.facebook.com/profile.php?id=61577661225593"
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 bg-white/10 rounded-full flex items-center justify-center hover:bg-[#1a56ff]/30 transition-colors"
                title="Facebook"
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" className="text-white/70">
                  <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/>
                </svg>
              </a>
            </div>
          </div>

          {/* Company */}
          <div>
            <h4 className="font-semibold text-white mb-4">{f.companyHeading}</h4>
            <ul className="space-y-3">
              {f.company.map((link) => (
                <li key={link.label}>
                  <a href={link.href} className="text-white/50 text-sm hover:text-[#1a56ff] transition-colors">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-semibold text-white mb-4">{f.servicesHeading}</h4>
            <ul className="space-y-3">
              {f.services.map((link) => (
                <li key={link.label}>
                  <a href={link.href} className="text-white/50 text-sm hover:text-[#1a56ff] transition-colors">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h4 className="font-semibold text-white mb-4">{f.legalHeading}</h4>
            <ul className="space-y-3">
              {f.legal.map((link) => (
                <li key={link.label}>
                  <a href={link.href} className="text-white/50 text-sm hover:text-[#1a56ff] transition-colors">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-white/10 pt-8">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-white/40 text-sm">
              {f.copyright.replace('{year}', String(new Date().getFullYear()))}
            </p>
            <p className="text-white/30 text-xs max-w-xl text-center sm:text-right">
              {f.disclaimer}
            </p>
          </div>
        </div>
      </div>
    </footer>
  )
}
