import { useLang } from '../i18n/LanguageContext'

export default function HowItWorks() {
  const { t } = useLang()
  const h = t.howItWorks
  const steps = h.steps

  return (
    <section id="how-it-works" className="py-20 bg-[#f9fafb]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <div className="text-center mb-4">
          <p className="text-[#1a56ff] text-sm font-semibold uppercase tracking-wider">{h.label}</p>
        </div>
        <h2
          className="text-3xl sm:text-4xl font-bold text-[#0a0f1e] text-center mb-4"
          style={{ fontFamily: 'Sora, Inter, sans-serif' }}
        >
          {h.heading}
        </h2>
        <p className="text-gray-500 text-center max-w-2xl mx-auto mb-16">
          {h.subheading}
        </p>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Steps */}
          <div className="space-y-8">
            {steps.map((step, index) => (
              <div key={index} className="flex gap-5">
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 rounded-full bg-[#1a56ff] text-white flex items-center justify-center font-bold text-lg shadow-lg shadow-blue-200">
                    {index + 1}
                  </div>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-[#0a0f1e] mb-2" style={{ fontFamily: 'Sora, Inter, sans-serif' }}>{step.title}</h3>
                  <p className="text-gray-500 leading-relaxed">{step.description}</p>
                </div>
              </div>
            ))}

            <div className="pt-4">
              <a
                href="/order?plan=us-premium"
                className="inline-flex items-center gap-2 bg-[#1a56ff] text-white font-semibold px-6 py-3 rounded-lg hover:bg-[#3a76ff] transition-colors"
              >
                {h.getStarted}
              </a>
            </div>
          </div>

          {/* Visual panel */}
          <div className="relative">
            <div className="rounded-2xl overflow-hidden shadow-2xl bg-[#0a0f1e] border border-white/10 p-8">
              <div className="space-y-6">
                {/* Timeline */}
                {steps.map((step, index) => (
                  <div key={index} className="flex gap-4 items-start">
                    <div className="flex flex-col items-center">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm flex-shrink-0 ${
                        index < 2 ? 'bg-[#16a34a] text-white' : 'bg-[#1a56ff] text-white'
                      }`}>
                        {index < 2 ? '✓' : index + 1}
                      </div>
                      {index < steps.length - 1 && (
                        <div className={`w-0.5 h-8 mt-1 ${index < 1 ? 'bg-[#16a34a]' : 'bg-[#1a56ff]/30'}`} />
                      )}
                    </div>
                    <div className="pt-1.5">
                      <p className={`text-sm font-semibold ${index < 2 ? 'text-[#16a34a]' : 'text-white'}`}>{step.title}</p>
                      <p className="text-white/40 text-xs mt-0.5">
                        {index === 0 ? h.completed : index === 1 ? h.completed : h.inProgress}
                      </p>
                    </div>
                  </div>
                ))}

                {/* Progress bar */}
                <div className="mt-6 pt-4 border-t border-white/10">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-white/50 text-xs">{h.formationProgress}</span>
                    <span className="text-[#1a56ff] text-xs font-semibold">75%</span>
                  </div>
                  <div className="w-full bg-white/10 rounded-full h-2">
                    <div className="bg-[#1a56ff] h-2 rounded-full" style={{ width: '75%' }} />
                  </div>
                </div>
              </div>
            </div>

            {/* Decorative element */}
            <div className="absolute -bottom-4 -right-4 w-24 h-24 bg-[#1a56ff]/10 rounded-2xl -z-10" />
            <div className="absolute -top-4 -left-4 w-16 h-16 bg-[#0a0f1e]/10 rounded-xl -z-10" />
          </div>
        </div>
      </div>
    </section>
  )
}
