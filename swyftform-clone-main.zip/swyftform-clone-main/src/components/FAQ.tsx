import { useState } from 'react'
import { ChevronDown } from 'lucide-react'
import { useLang } from '../i18n/LanguageContext'

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0)
  const { t } = useLang()
  const f = t.faq

  return (
    <section id="faq" className="py-20 bg-[#f9fafb]">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-4">
          <p className="text-[#1a56ff] text-sm font-semibold uppercase tracking-wider">{f.label}</p>
        </div>
        <h2
          className="text-3xl sm:text-4xl font-bold text-[#0a0f1e] text-center mb-12"
          style={{ fontFamily: 'Sora, Inter, sans-serif' }}
        >
          {f.heading}
        </h2>

        <div className="space-y-3">
          {f.items.map((faq, index) => (
            <div
              key={index}
              className="bg-white rounded-2xl border border-gray-100 overflow-hidden shadow-sm hover:shadow-md transition-shadow"
            >
              <button
                className="w-full flex items-center justify-between px-6 py-5 text-left"
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
              >
                <span className="font-semibold text-[#0a0f1e] pr-4">{faq.question}</span>
                <ChevronDown
                  size={20}
                  className={`text-gray-400 flex-shrink-0 transition-transform duration-200 ${
                    openIndex === index ? 'rotate-180 text-[#1a56ff]' : ''
                  }`}
                />
              </button>

              {openIndex === index && (
                <div className="px-6 pb-5">
                  <p className="text-gray-500 leading-relaxed text-sm">{faq.answer}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
