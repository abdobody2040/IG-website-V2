import { Star } from 'lucide-react'
import { useLang } from '../i18n/LanguageContext'

const reviewMeta = [
  { name: 'KK M', country: 'Egypt', date: 'Mar 6, 2026', initials: 'KK' },
  { name: 'El-Joudeh', country: 'United Kingdom', date: 'Mar 3, 2026', initials: 'EJ' },
  { name: 'Shahed Alkhateeb', country: 'Jordan', date: 'Feb 28, 2026', initials: 'SA' },
  { name: 'Plantlyze Team', country: 'Egypt', date: 'Jan 25, 2026', initials: 'PT' },
]

const avatarColors = ['#1a56ff', '#0a0f1e', '#059669', '#7C3AED']

export default function Reviews() {
  const { t } = useLang()
  const r = t.reviews

  return (
    <section id="reviews" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-4">
          <p className="text-[#1a56ff] text-sm font-semibold uppercase tracking-wider">{r.label}</p>
        </div>
        <h2
          className="text-3xl sm:text-4xl font-bold text-[#0a0f1e] text-center mb-4"
          style={{ fontFamily: 'Sora, Inter, sans-serif' }}
        >
          {r.heading}
        </h2>
        <p className="text-gray-500 text-center max-w-2xl mx-auto mb-6">
          {r.subheading}
        </p>

        {/* Trustpilot rating */}
        <div className="flex flex-col items-center gap-2 mb-12">
          <div className="flex items-center gap-1">
            {[...Array(5)].map((_, i) => (
              <Star key={i} size={28} className="fill-[#00B67A] text-[#00B67A]" />
            ))}
          </div>
          <div className="flex items-center gap-2">
            <span className="text-2xl font-bold text-[#0a0f1e]">5.0</span>
            <span className="text-gray-500 text-sm">/ 5</span>
          </div>
          <a
            href="https://www.trustpilot.com/review/instantgrow.net"
            target="_blank"
            rel="noopener noreferrer"
            className="text-sm text-gray-400 hover:text-[#1a56ff] transition-colors"
          >
            {r.viewAll}
          </a>
        </div>

        {/* Review cards */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {r.items.map((review, i) => (
            <div
              key={i}
              className="bg-white border border-gray-100 rounded-2xl p-6 shadow-sm hover:shadow-md hover:border-[#1a56ff]/20 transition-all duration-300"
            >
              {/* Stars */}
              <div className="flex gap-0.5 mb-4">
                {[...Array(5)].map((_, j) => (
                  <Star key={j} size={14} className="fill-[#00B67A] text-[#00B67A]" />
                ))}
              </div>

              <h4 className="font-semibold text-[#0a0f1e] text-sm mb-2 leading-snug">{review.title}</h4>
              <p className="text-gray-500 text-xs leading-relaxed mb-4">{review.body}</p>

              {/* Author */}
              <div className="flex items-center gap-3 pt-4 border-t border-gray-100">
                <div
                  className="w-9 h-9 rounded-full flex items-center justify-center text-white text-xs font-bold flex-shrink-0"
                  style={{ backgroundColor: avatarColors[i % avatarColors.length] }}
                >
                  {reviewMeta[i].initials}
                </div>
                <div>
                  <p className="text-sm font-medium text-[#0a0f1e]">{reviewMeta[i].name}</p>
                  <p className="text-xs text-gray-400">{reviewMeta[i].country} · {reviewMeta[i].date}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Verified badge */}
        <div className="text-center mt-10">
          <a
            href="https://www.trustpilot.com/review/instantgrow.net"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 border border-[#00B67A]/30 text-[#00B67A] text-sm font-medium px-5 py-2.5 rounded-full hover:bg-[#00B67A]/5 transition-colors"
          >
            <div className="flex gap-0.5">
              {[...Array(5)].map((_, i) => (
                <Star key={i} size={10} className="fill-[#00B67A] text-[#00B67A]" />
              ))}
            </div>
            {r.verified}
          </a>
        </div>
      </div>
    </section>
  )
}
