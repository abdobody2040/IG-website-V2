import { ArrowRight, Sparkles } from 'lucide-react'
import { useLang } from '../i18n/LanguageContext'

export default function CTASection() {
  const { t } = useLang()
  const c = t.cta

  return (
    <section id="order" className="py-20 bg-[#0a0f1e] relative overflow-hidden">
      {/* Decorative sparkle elements */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {/* Large glow spots */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-[#1a56ff]/15 rounded-full blur-3xl" />
        <div className="absolute top-0 right-0 w-64 h-64 bg-[#00d4ff]/5 rounded-full blur-2xl" />
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-white/5 rounded-full blur-2xl" />

        {/* Subtle grid */}
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage: 'linear-gradient(rgba(255,255,255,0.6) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.6) 1px, transparent 1px)',
            backgroundSize: '48px 48px',
          }}
        />

        {/* Small sparkle dots */}
        {[...Array(8)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-[#1a56ff]/40 rounded-full"
            style={{
              top: `${15 + Math.sin(i * 45 * Math.PI / 180) * 35 + 35}%`,
              left: `${15 + Math.cos(i * 45 * Math.PI / 180) * 35 + 35}%`,
            }}
          />
        ))}
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
        <div className="flex justify-center mb-4">
          <div className="bg-[#1a56ff]/20 rounded-full p-3">
            <Sparkles size={24} className="text-[#1a56ff]" />
          </div>
        </div>

        <p className="text-[#00d4ff] text-sm font-semibold uppercase tracking-wider mb-3">{c.label}</p>
        <h2
          className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6 leading-tight"
          style={{ fontFamily: 'Sora, Inter, sans-serif' }}
        >
          {c.heading}
        </h2>
        <p className="text-white/70 text-lg mb-10 max-w-2xl mx-auto">
          {c.subheading}
        </p>

        <a
          href="/order?plan=us-premium"
          className="inline-flex items-center gap-2 bg-[#1a56ff] text-white font-bold text-lg px-10 py-4 rounded-xl hover:bg-[#3a76ff] transition-all hover:shadow-2xl hover:shadow-blue-500/30 hover:-translate-y-0.5"
        >
          {c.button}
          <ArrowRight size={20} />
        </a>

        <p className="text-white/40 text-sm mt-6">
          {c.note}
        </p>
      </div>
    </section>
  )
}
