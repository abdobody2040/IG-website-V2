import { useState, useRef } from 'react'
import { useParams, Link } from '@tanstack/react-router'
import {
  ArrowLeft, User, Mail, Phone, Shield, ShoppingBag, Building2,
  FileText, CreditCard, Edit2, Trash2, X, Loader2, CheckCircle,
  ExternalLink, Plus, Calendar, Hash
} from 'lucide-react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import AdminLayout from './AdminLayout'
import { supabase } from '../../lib/supabase'
import { useRequireAdmin } from '../../hooks/useRequireAuth'
import toast from 'react-hot-toast'
import type { Order, Company, Document, User as UserType } from '../../types/db'
import { format } from 'date-fns'

// ── Status badges ──────────────────────────────────────────────────────────
const statusColors: Record<string, string> = {
  pending:         'bg-amber-50 text-amber-700 border-amber-200',
  in_review:       'bg-blue-50 text-blue-700 border-blue-200',
  processing:      'bg-blue-50 text-blue-700 border-blue-200',
  documents_filed: 'bg-indigo-50 text-indigo-700 border-indigo-200',
  ein_processing:  'bg-purple-50 text-purple-700 border-purple-200',
  completed:       'bg-green-50 text-green-700 border-green-200',
  cancelled:       'bg-red-50 text-red-700 border-red-200',
  active:          'bg-green-50 text-green-700 border-green-200',
  suspended:       'bg-red-50 text-red-700 border-red-200',
  paid:            'bg-green-50 text-green-700 border-green-200',
  failed:          'bg-red-50 text-red-700 border-red-200',
  refunded:        'bg-slate-100 text-slate-600 border-slate-200',
  ready:           'bg-green-50 text-green-700 border-green-200',
}
function StatusBadge({ status }: { status: string }) {
  const cls = statusColors[status] ?? 'bg-slate-100 text-slate-600 border-slate-200'
  return (
    <span className={`inline-flex items-center text-xs font-semibold px-2.5 py-0.5 rounded-full border ${cls}`}>
      {status.replace(/_/g, ' ')}
    </span>
  )
}

// ── Confirm delete modal ───────────────────────────────────────────────────
function ConfirmDeleteModal({ label, onConfirm, onCancel, loading }: {
  label: string; onConfirm: () => void; onCancel: () => void; loading: boolean
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-sm w-full p-6">
        <h3 className="font-semibold text-slate-900 mb-2">Delete {label}?</h3>
        <p className="text-sm text-slate-500 mb-6">This action cannot be undone.</p>
        <div className="flex gap-3">
          <button onClick={onCancel} className="flex-1 py-2 rounded-lg border border-slate-200 text-slate-700 text-sm font-medium hover:bg-slate-50">Cancel</button>
          <button onClick={onConfirm} disabled={loading} className="flex-1 py-2 rounded-lg bg-red-500 text-white text-sm font-semibold hover:bg-red-600 disabled:opacity-60 flex items-center justify-center gap-2">
            {loading && <Loader2 size={13} className="animate-spin" />} Delete
          </button>
        </div>
      </div>
    </div>
  )
}

// ── Order STATUS_OPTIONS ───────────────────────────────────────────────────
const ORDER_STATUS_OPTIONS = [
  'pending','in_review','processing','documents_filed','ein_processing','completed','cancelled'
]
const COMPANY_STATUS_OPTIONS = ['pending','active','suspended','completed']
const DOC_STATUS_OPTIONS = ['pending','ready']
const DOC_TYPE_OPTIONS = ['articles_of_org','operating_agreement','ein_letter','banking_resolution','other']
const PAYMENT_STATUS_OPTIONS = ['pending','paid','failed','refunded']

// ── Edit Order Modal ───────────────────────────────────────────────────────
function EditOrderModal({ order, onClose, onSaved }: { order: Order; onClose: () => void; onSaved: () => void }) {
  const [form, setForm] = useState({
    companyName: order.companyName,
    companyState: order.companyState,
    companyType: order.companyType,
    packageName: order.packageName,
    amount: String(order.amount),
    currency: order.currency,
    status: order.status,
    notes: order.notes,
  })
  const [saving, setSaving] = useState(false)

  async function handleSave() {
    setSaving(true)
    try {
      const statusChanged = form.status !== order.status
      const { error: updateErr } = await supabase.from('orders').update({
        company_name: form.companyName,
        company_state: form.companyState,
        company_type: form.companyType,
        package_name: form.packageName,
        amount: parseFloat(form.amount) || 0,
        currency: form.currency,
        status: form.status,
        notes: form.notes,
        updated_at: new Date().toISOString(),
      }).eq('id', order.id)
      if (updateErr) throw updateErr
      if (statusChanged) {
        const { error: insertErr } = await supabase.from('order_updates').insert({
          order_id: order.id,
          status: form.status,
          message: `Status updated to ${form.status} by admin`,
          created_by: 'admin',
          created_at: new Date().toISOString(),
        })
        if (insertErr) throw insertErr
      }
      toast.success('Order updated')
      onSaved()
      onClose()
    } catch { toast.error('Failed to save') }
    finally { setSaving(false) }
  }

  const F = ({ label, field, type = 'text' }: { label: string; field: keyof typeof form; type?: string }) => (
    <div>
      <label className="block text-xs font-medium text-slate-700 mb-1">{label}</label>
      <input type={type} value={form[field]} onChange={e => setForm(f => ({ ...f, [field]: e.target.value }))}
        className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-[#1a56ff]" />
    </div>
  )

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-5 border-b border-slate-100">
          <h3 className="font-semibold text-slate-900">Edit Order #{order.orderNumber}</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600"><X size={18} /></button>
        </div>
        <div className="p-5 grid grid-cols-2 gap-4">
          <F label="Company Name" field="companyName" />
          <F label="State" field="companyState" />
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Type</label>
            <select value={form.companyType} onChange={e => setForm(f => ({ ...f, companyType: e.target.value }))}
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-[#1a56ff] bg-white">
              <option value="LLC">LLC</option><option value="LTD">LTD</option>
            </select>
          </div>
          <F label="Package" field="packageName" />
          <F label="Amount ($)" field="amount" type="number" />
          <F label="Currency" field="currency" />
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Status</label>
            <select value={form.status} onChange={e => setForm(f => ({ ...f, status: e.target.value }))}
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-[#1a56ff] bg-white">
              {ORDER_STATUS_OPTIONS.map(s => <option key={s} value={s}>{s.replace(/_/g, ' ')}</option>)}
            </select>
          </div>
          <div className="col-span-2">
            <label className="block text-xs font-medium text-slate-700 mb-1">Notes</label>
            <textarea value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} rows={3}
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-[#1a56ff] resize-none" />
          </div>
        </div>
        <div className="flex gap-3 p-5 border-t border-slate-100">
          <button onClick={onClose} className="flex-1 py-2.5 rounded-lg border border-slate-200 text-slate-700 text-sm font-medium hover:bg-slate-50">Cancel</button>
          <button onClick={handleSave} disabled={saving} className="flex-1 py-2.5 rounded-lg bg-[#1a56ff] text-white text-sm font-semibold hover:bg-[#1440d0] disabled:opacity-60 flex items-center justify-center gap-2">
            {saving && <Loader2 size={13} className="animate-spin" />} Save Changes
          </button>
        </div>
      </div>
    </div>
  )
}

// ── Edit Company Modal ─────────────────────────────────────────────────────
function EditCompanyModal({ company, onClose, onSaved }: { company: Company; onClose: () => void; onSaved: () => void }) {
  const [form, setForm] = useState({
    companyName: company.companyName,
    companyType: company.companyType,
    state: company.state,
    einNumber: company.einNumber,
    formationDate: company.formationDate,
    registeredAgent: company.registeredAgent,
    status: company.status,
  })
  const [saving, setSaving] = useState(false)

  async function handleSave() {
    setSaving(true)
    try {
      const { error: updateErr } = await supabase.from('companies').update({
        company_name: form.companyName,
        company_type: form.companyType,
        state: form.state,
        ein_number: form.einNumber,
        formation_date: form.formationDate,
        registered_agent: form.registeredAgent,
        status: form.status,
        updated_at: new Date().toISOString(),
      }).eq('id', company.id)
      if (updateErr) throw updateErr
      toast.success('Company updated')
      onSaved()
      onClose()
    } catch { toast.error('Failed to save') }
    finally { setSaving(false) }
  }

  const F = ({ label, field }: { label: string; field: keyof typeof form }) => (
    <div>
      <label className="block text-xs font-medium text-slate-700 mb-1">{label}</label>
      <input value={form[field]} onChange={e => setForm(f => ({ ...f, [field]: e.target.value }))}
        className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-[#1a56ff]" />
    </div>
  )

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-5 border-b border-slate-100">
          <h3 className="font-semibold text-slate-900">Edit Company</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600"><X size={18} /></button>
        </div>
        <div className="p-5 grid grid-cols-2 gap-4">
          <div className="col-span-2"><F label="Company Name" field="companyName" /></div>
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Type</label>
            <select value={form.companyType} onChange={e => setForm(f => ({ ...f, companyType: e.target.value }))}
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-[#1a56ff] bg-white">
              <option>LLC</option><option>LTD</option>
            </select>
          </div>
          <F label="State" field="state" />
          <F label="EIN Number" field="einNumber" />
          <F label="Formation Date" field="formationDate" />
          <div className="col-span-2"><F label="Registered Agent" field="registeredAgent" /></div>
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Status</label>
            <select value={form.status} onChange={e => setForm(f => ({ ...f, status: e.target.value }))}
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-[#1a56ff] bg-white">
              {COMPANY_STATUS_OPTIONS.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
        </div>
        <div className="flex gap-3 p-5 border-t border-slate-100">
          <button onClick={onClose} className="flex-1 py-2.5 rounded-lg border border-slate-200 text-slate-700 text-sm font-medium hover:bg-slate-50">Cancel</button>
          <button onClick={handleSave} disabled={saving} className="flex-1 py-2.5 rounded-lg bg-[#1a56ff] text-white text-sm font-semibold hover:bg-[#1440d0] disabled:opacity-60 flex items-center justify-center gap-2">
            {saving && <Loader2 size={13} className="animate-spin" />} Save
          </button>
        </div>
      </div>
    </div>
  )
}

// ── Edit Document Modal ────────────────────────────────────────────────────
function EditDocumentModal({ doc, onClose, onSaved }: { doc: Document; onClose: () => void; onSaved: () => void }) {
  const [form, setForm] = useState({ name: doc.name, docType: doc.docType, fileUrl: doc.fileUrl, status: doc.status })
  const [saving, setSaving] = useState(false)

  async function handleSave() {
    setSaving(true)
    try {
      const { error: updateErr } = await supabase.from('documents').update({
        name: form.name,
        doc_type: form.docType,
        file_url: form.fileUrl,
        status: form.status,
        updated_at: new Date().toISOString(),
      }).eq('id', doc.id)
      if (updateErr) throw updateErr
      toast.success('Document updated')
      onSaved()
      onClose()
    } catch { toast.error('Failed to save') }
    finally { setSaving(false) }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-md">
        <div className="flex items-center justify-between p-5 border-b border-slate-100">
          <h3 className="font-semibold text-slate-900">Edit Document</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600"><X size={18} /></button>
        </div>
        <div className="p-5 space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Name</label>
            <input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-[#1a56ff]" />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Type</label>
            <select value={form.docType} onChange={e => setForm(f => ({ ...f, docType: e.target.value }))}
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-[#1a56ff] bg-white">
              {DOC_TYPE_OPTIONS.map(t => <option key={t} value={t}>{t.replace(/_/g, ' ')}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Status</label>
            <select value={form.status} onChange={e => setForm(f => ({ ...f, status: e.target.value }))}
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-[#1a56ff] bg-white">
              {DOC_STATUS_OPTIONS.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">File URL</label>
            <input value={form.fileUrl} onChange={e => setForm(f => ({ ...f, fileUrl: e.target.value }))}
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-[#1a56ff]" />
          </div>
        </div>
        <div className="flex gap-3 p-5 border-t border-slate-100">
          <button onClick={onClose} className="flex-1 py-2.5 rounded-lg border border-slate-200 text-slate-700 text-sm font-medium hover:bg-slate-50">Cancel</button>
          <button onClick={handleSave} disabled={saving} className="flex-1 py-2.5 rounded-lg bg-[#1a56ff] text-white text-sm font-semibold hover:bg-[#1440d0] disabled:opacity-60 flex items-center justify-center gap-2">
            {saving && <Loader2 size={13} className="animate-spin" />} Save
          </button>
        </div>
      </div>
    </div>
  )
}

// ── Add Document Modal ─────────────────────────────────────────────────────
const ACCEPTED_FILE_TYPES = '.pdf,.doc,.docx,.png,.jpg,.jpeg,.webp'
const ALLOWED_MIME_TYPES = [
  'application/pdf', 'image/png', 'image/jpeg', 'image/webp',
  'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
]
const MAX_FILE_SIZE = 10 * 1024 * 1024

function AddDocumentModal({ userId, orders, companies, onClose, onSaved }: {
  userId: string; orders: Order[]; companies: Company[]; onClose: () => void; onSaved: () => void
}) {
  const [form, setForm] = useState({ docType: 'other', status: 'ready', orderId: '', companyId: '' })
  const [file, setFile] = useState<File | null>(null)
  const [dragging, setDragging] = useState(false)
  const [uploading, setUploading] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)

  function handleFiles(files: FileList | null) {
    if (!files?.length) return
    const f = files[0]
    if (!ALLOWED_MIME_TYPES.includes(f.type)) {
      toast.error('File type not allowed. Accepted: PDF, PNG, JPEG, WEBP, DOC, DOCX.')
      return
    }
    if (f.size > MAX_FILE_SIZE) {
      toast.error('File too large. Maximum size is 10 MB.')
      return
    }
    setFile(f)
  }

  function onDrop(e: React.DragEvent) {
    e.preventDefault()
    setDragging(false)
    handleFiles(e.dataTransfer.files)
  }

  async function handleSave() {
    if (!file) { toast.error('Please select a file'); return }
    if (file.size > MAX_FILE_SIZE) { toast.error('File too large. Maximum size is 10 MB.'); return }
    setUploading(true)
    try {
      const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, '_')
      const path = `user-docs/${userId}/${Date.now()}-${safeName}`
      let publicUrl: string

      const R2_UPLOAD_ENDPOINT = import.meta.env.VITE_R2_UPLOAD_ENDPOINT as string | undefined
      if (R2_UPLOAD_ENDPOINT) {
        const { data: { session } } = await supabase.auth.getSession()
        const formData = new FormData()
        formData.append('file', file)
        formData.append('path', path)
        const res = await fetch(R2_UPLOAD_ENDPOINT, {
          method: 'POST',
          headers: session?.access_token ? { Authorization: `Bearer ${session.access_token}` } : {},
          body: formData,
        })
        if (!res.ok) throw new Error('Upload to R2 failed')
        const json = await res.json()
        publicUrl = json.url
      } else {
        const { error: uploadError } = await supabase.storage.from('documents').upload(path, file, { upsert: true })
        if (uploadError) throw uploadError
        const { data: urlData } = supabase.storage.from('documents').getPublicUrl(path)
        publicUrl = urlData.publicUrl
      }

      const now = new Date().toISOString()
      const { error: insertErr } = await supabase.from('documents').insert({
        user_id: userId,
        order_id: form.orderId || null,
        company_id: form.companyId || null,
        name: file.name,
        doc_type: form.docType,
        file_url: publicUrl,
        file_name: safeName,
        status: form.status,
        created_at: now,
        updated_at: now,
      })
      if (insertErr) throw insertErr
      toast.success('Document uploaded')
      onSaved()
      onClose()
    } catch { toast.error('Failed to upload document') }
    finally { setUploading(false) }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-md">
        <div className="flex items-center justify-between p-5 border-b border-slate-100">
          <h3 className="font-semibold text-slate-900">Add Document for Client</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600"><X size={18} /></button>
        </div>
        <div className="p-5 space-y-4">
          {/* File upload area */}
          {!file ? (
            <div
              onDragOver={e => { e.preventDefault(); setDragging(true) }}
              onDragLeave={() => setDragging(false)}
              onDrop={onDrop}
              onClick={() => fileRef.current?.click()}
              className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all ${dragging ? 'border-[#1a56ff] bg-blue-50' : 'border-slate-200 hover:border-[#1a56ff]/50 hover:bg-slate-50'}`}
            >
              <Plus size={28} className={`mx-auto mb-2 ${dragging ? 'text-[#1a56ff]' : 'text-slate-300'}`} />
              <p className="text-sm font-medium text-slate-700">Drag & drop or <span className="text-[#1a56ff]">browse</span></p>
              <p className="text-xs text-slate-400 mt-1">PDF, DOC, JPG, PNG — max 10 MB</p>
              <input ref={fileRef} type="file" accept={ACCEPTED_FILE_TYPES} className="hidden" onChange={e => handleFiles(e.target.files)} />
            </div>
          ) : (
            <div className="flex items-center gap-3 bg-blue-50 border border-blue-100 rounded-xl px-4 py-3">
              <FileText size={18} className="text-[#1a56ff] flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-slate-900 truncate">{file.name}</p>
                <p className="text-xs text-slate-500">{(file.size / 1024).toFixed(1)} KB</p>
              </div>
              <button onClick={() => setFile(null)} className="text-slate-400 hover:text-red-500"><X size={16} /></button>
            </div>
          )}

          {/* Order dropdown */}
          {orders.length > 0 && (
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Link to Order (optional)</label>
              <select value={form.orderId} onChange={e => setForm(f => ({ ...f, orderId: e.target.value }))}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-[#1a56ff] bg-white">
                <option value="">— None —</option>
                {orders.map(o => <option key={o.id} value={o.id}>#{o.orderNumber} — {o.companyName}</option>)}
              </select>
            </div>
          )}

          {/* Company dropdown */}
          {companies.length > 0 && (
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Link to Company (optional)</label>
              <select value={form.companyId} onChange={e => setForm(f => ({ ...f, companyId: e.target.value }))}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-[#1a56ff] bg-white">
                <option value="">— None —</option>
                {companies.map(c => <option key={c.id} value={c.id}>{c.companyName} ({c.state})</option>)}
              </select>
            </div>
          )}

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Type</label>
            <select value={form.docType} onChange={e => setForm(f => ({ ...f, docType: e.target.value }))}
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-[#1a56ff] bg-white">
              {DOC_TYPE_OPTIONS.map(t => <option key={t} value={t}>{t.replace(/_/g, ' ')}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Status</label>
            <select value={form.status} onChange={e => setForm(f => ({ ...f, status: e.target.value }))}
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-[#1a56ff] bg-white">
              {DOC_STATUS_OPTIONS.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
        </div>
        <div className="flex gap-3 p-5 border-t border-slate-100">
          <button onClick={onClose} className="flex-1 py-2.5 rounded-lg border border-slate-200 text-slate-700 text-sm font-medium hover:bg-slate-50">Cancel</button>
          <button onClick={handleSave} disabled={uploading || !file} className="flex-1 py-2.5 rounded-lg bg-[#1a56ff] text-white text-sm font-semibold hover:bg-[#1440d0] disabled:opacity-60 flex items-center justify-center gap-2">
            {uploading && <Loader2 size={13} className="animate-spin" />} {uploading ? 'Uploading...' : 'Upload Document'}
          </button>
        </div>
      </div>
    </div>
  )
}

// ── Edit Payment Modal ─────────────────────────────────────────────────────
function EditPaymentModal({ payment, onClose, onSaved }: { payment: any; onClose: () => void; onSaved: () => void }) {
  const [form, setForm] = useState({ service: payment.service, amount: String(payment.amount), status: payment.status, currency: payment.currency })
  const [saving, setSaving] = useState(false)

  async function handleSave() {
    setSaving(true)
    try {
      const { error: updateErr } = await supabase.from('payments').update({
        service: form.service,
        amount: parseFloat(form.amount) || 0,
        status: form.status,
        currency: form.currency,
        updated_at: new Date().toISOString(),
      }).eq('id', payment.id)
      if (updateErr) throw updateErr
      toast.success('Payment updated')
      onSaved()
      onClose()
    } catch { toast.error('Failed to save') }
    finally { setSaving(false) }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-sm">
        <div className="flex items-center justify-between p-5 border-b border-slate-100">
          <h3 className="font-semibold text-slate-900">Edit Payment</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600"><X size={18} /></button>
        </div>
        <div className="p-5 space-y-4">
          {([['Service', 'service'], ['Amount', 'amount'], ['Currency', 'currency']] as const).map(([label, field]) => (
            <div key={field}>
              <label className="block text-xs font-medium text-slate-700 mb-1">{label}</label>
              <input value={form[field]} onChange={e => setForm(f => ({ ...f, [field]: e.target.value }))}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-[#1a56ff]" />
            </div>
          ))}
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Status</label>
            <select value={form.status} onChange={e => setForm(f => ({ ...f, status: e.target.value }))}
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-[#1a56ff] bg-white">
              {PAYMENT_STATUS_OPTIONS.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
        </div>
        <div className="flex gap-3 p-5 border-t border-slate-100">
          <button onClick={onClose} className="flex-1 py-2.5 rounded-lg border border-slate-200 text-slate-700 text-sm font-medium hover:bg-slate-50">Cancel</button>
          <button onClick={handleSave} disabled={saving} className="flex-1 py-2.5 rounded-lg bg-[#1a56ff] text-white text-sm font-semibold disabled:opacity-60 flex items-center justify-center gap-2">
            {saving && <Loader2 size={13} className="animate-spin" />} Save
          </button>
        </div>
      </div>
    </div>
  )
}

// ── Edit User Drawer ───────────────────────────────────────────────────────
function EditUserDrawer({ user, onClose, onSaved }: { user: UserType; onClose: () => void; onSaved: () => void }) {
  const [form, setForm] = useState({
    displayName: user.displayName || '',
    email: user.email || '',
    phone: user.phone || '',
    role: user.role || 'client',
  })
  const [saving, setSaving] = useState(false)

  async function handleSave() {
    setSaving(true)
    try {
      const { error: updateErr } = await supabase.from('profiles').update({
        display_name: form.displayName,
        email: form.email,
        phone: form.phone,
        role: form.role,
        updated_at: new Date().toISOString(),
      }).eq('id', user.id)
      if (updateErr) throw updateErr
      toast.success('User updated')
      onSaved()
      onClose()
    } catch { toast.error('Failed to save') }
    finally { setSaving(false) }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center sm:justify-end bg-black/40 backdrop-blur-sm">
      <div className="bg-white w-full sm:w-96 sm:h-full sm:max-h-screen overflow-y-auto shadow-2xl rounded-t-2xl sm:rounded-none">
        <div className="flex items-center justify-between p-5 border-b border-slate-100">
          <h3 className="font-semibold text-slate-900">Edit User</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600"><X size={18} /></button>
        </div>

        {/* Read-only info */}
        <div className="px-5 py-4 bg-slate-50 border-b border-slate-100">
          <p className="text-xs font-medium text-slate-500 uppercase mb-2">Account Info</p>
          <div className="space-y-1 text-xs text-slate-600">
            <div className="flex gap-2"><span className="text-slate-400 w-16">ID:</span><span className="font-mono">{user.id.slice(0, 16)}…</span></div>
            <div className="flex gap-2"><span className="text-slate-400 w-16">Email:</span><span>{user.email}</span></div>
            <div className="flex gap-2"><span className="text-slate-400 w-16">Joined:</span><span>{user.createdAt ? format(new Date(user.createdAt), 'MMM d, yyyy') : '—'}</span></div>
            <div className="flex gap-2"><span className="text-slate-400 w-16">Last login:</span><span>{user.lastSignIn ? format(new Date(user.lastSignIn), 'MMM d, yyyy') : '—'}</span></div>
          </div>
        </div>

        <div className="p-5 space-y-4">
          {[
            { label: 'Display Name', field: 'displayName' as const },
            { label: 'Phone', field: 'phone' as const },
          ].map(({ label, field }) => (
            <div key={field}>
              <label className="block text-xs font-medium text-slate-700 mb-1">{label}</label>
              <input value={form[field]} onChange={e => setForm(f => ({ ...f, [field]: e.target.value }))}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-[#1a56ff]" />
            </div>
          ))}
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Role</label>
            <select value={form.role} onChange={e => setForm(f => ({ ...f, role: e.target.value }))}
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-[#1a56ff] bg-white">
              <option value="client">Client</option>
              <option value="admin">Admin</option>
            </select>
          </div>

        </div>

        <div className="flex gap-3 p-5 border-t border-slate-100">
          <button onClick={onClose} className="flex-1 py-2.5 rounded-lg border border-slate-200 text-slate-700 text-sm font-medium hover:bg-slate-50">Cancel</button>
          <button onClick={handleSave} disabled={saving} className="flex-1 py-2.5 rounded-lg bg-[#1a56ff] text-white text-sm font-semibold hover:bg-[#1440d0] disabled:opacity-60 flex items-center justify-center gap-2">
            {saving && <Loader2 size={13} className="animate-spin" />} Save Changes
          </button>
        </div>
      </div>
    </div>
  )
}

// ── Main page ──────────────────────────────────────────────────────────────
export default function AdminClientDetailPage() {
  const { isLoading: authLoading } = useRequireAdmin()
  const { userId } = useParams({ from: '/admin/clients/$userId' })
  const qc = useQueryClient()

  // Fetch user
  const { data: user, isLoading: userLoading } = useQuery({
    queryKey: ['admin', 'user', userId],
    queryFn: async () => {
      const { data, error } = await supabase.from('profiles').select('*').eq('id', userId).single()
      if (error) throw error
      return {
        id: data.id,
        email: data.email ?? '',
        displayName: data.display_name ?? '',
        phone: data.phone ?? '',
        role: data.role ?? 'client',
        avatarUrl: data.avatar_url ?? '',
        emailVerified: data.email_verified ?? false,
        phoneVerified: data.phone_verified ?? false,
        country: data.country ?? '',
        address: data.address ?? '',
        createdAt: data.created_at ?? '',
        updatedAt: data.updated_at ?? '',
        lastSignIn: data.last_sign_in ?? '',
        metadata: data.metadata ?? '{}',
      } as UserType
    },
    enabled: !!userId,
  })

  // Fetch this user's data
  const { data: orders = [] } = useQuery({
    queryKey: ['admin', 'user-orders', userId],
    queryFn: async () => {
      const { data, error } = await supabase.from('orders').select('*').eq('user_id', userId).order('created_at', { ascending: false })
      if (error) throw error
      return (data ?? []).map((r: Record<string, unknown>) => ({
        id: r.id as string,
        userId: r.user_id as string,
        orderNumber: r.order_number as string,
        packageName: r.package_name as string,
        companyName: r.company_name as string,
        companyState: r.company_state as string,
        companyType: r.company_type as string,
        status: r.status as string,
        amount: r.amount as number,
        currency: r.currency as string,
        notes: (r.notes as string) ?? '',
        createdAt: r.created_at as string,
        updatedAt: r.updated_at as string,
      })) as Order[]
    },
    enabled: !!userId,
  })

  const { data: companies = [] } = useQuery({
    queryKey: ['admin', 'user-companies', userId],
    queryFn: async () => {
      const { data, error } = await supabase.from('companies').select('*').eq('user_id', userId).order('created_at', { ascending: false })
      if (error) throw error
      return (data ?? []).map((r: Record<string, unknown>) => ({
        id: r.id as string,
        userId: r.user_id as string,
        orderId: r.order_id as string,
        companyName: r.company_name as string,
        companyType: r.company_type as string,
        state: r.state as string,
        einNumber: r.ein_number as string,
        formationDate: r.formation_date as string,
        registeredAgent: r.registered_agent as string,
        status: r.status as string,
        createdAt: r.created_at as string,
        updatedAt: r.updated_at as string,
      })) as Company[]
    },
    enabled: !!userId,
  })

  const { data: documents = [] } = useQuery({
    queryKey: ['admin', 'user-documents', userId],
    queryFn: async () => {
      const { data, error } = await supabase.from('documents').select('*').eq('user_id', userId).order('created_at', { ascending: false })
      if (error) throw error
      return (data ?? []).map((r: Record<string, unknown>) => ({
        id: r.id as string,
        userId: r.user_id as string,
        orderId: r.order_id as string,
        companyId: r.company_id as string,
        name: r.name as string,
        docType: r.doc_type as string,
        fileUrl: (r.file_url as string) ?? '',
        fileName: (r.file_name as string) ?? '',
        status: r.status as string,
        notes: (r.notes as string) ?? '',
        createdAt: r.created_at as string,
        updatedAt: r.updated_at as string,
      })) as Document[]
    },
    enabled: !!userId,
  })

  const { data: payments = [] } = useQuery({
    queryKey: ['admin', 'user-payments', userId],
    queryFn: async () => {
      const { data, error } = await supabase.from('payments').select('*').eq('user_id', userId).order('created_at', { ascending: false })
      if (error) throw error
      return (data ?? []).map((r: Record<string, unknown>) => ({
        id: r.id as string,
        userId: r.user_id as string,
        orderId: r.order_id as string,
        service: r.service as string,
        invoiceId: r.invoice_id as string,
        amount: r.amount as number,
        currency: r.currency as string,
        status: r.status as string,
        stripePaymentId: (r.stripe_payment_id as string) ?? '',
        notes: r.notes as string,
        createdAt: r.created_at as string,
        updatedAt: r.updated_at as string,
      }))
    },
    enabled: !!userId,
  })

  // Modal state
  const [editUser, setEditUser] = useState(false)
  const [editOrder, setEditOrder] = useState<Order | null>(null)
  const [editCompany, setEditCompany] = useState<Company | null>(null)
  const [editDoc, setEditDoc] = useState<Document | null>(null)
  const [addDoc, setAddDoc] = useState(false)
  const [editPayment, setEditPayment] = useState<any | null>(null)
  const [deleteTarget, setDeleteTarget] = useState<{ type: string; id: string; label: string } | null>(null)
  const [deleting, setDeleting] = useState(false)

  if (authLoading) return <div className="flex items-center justify-center h-screen"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#1a56ff]" /></div>

  const refetchAll = () => {
    qc.invalidateQueries({ queryKey: ['admin', 'user', userId] })
    qc.invalidateQueries({ queryKey: ['admin', 'user-orders', userId] })
    qc.invalidateQueries({ queryKey: ['admin', 'user-companies', userId] })
    qc.invalidateQueries({ queryKey: ['admin', 'user-documents', userId] })
    qc.invalidateQueries({ queryKey: ['admin', 'user-payments', userId] })
    qc.invalidateQueries({ queryKey: ['admin', 'users'] })
  }

  async function handleDelete() {
    if (!deleteTarget) return
    setDeleting(true)
    try {
      const tableMap: Record<string, string> = { order: 'orders', company: 'companies', document: 'documents', payment: 'payments' }
      const table = tableMap[deleteTarget.type]
      const { error: delErr } = await supabase.from(table).delete().eq('id', deleteTarget.id)
      if (delErr) throw delErr
      toast.success(`${deleteTarget.type} deleted`)
      refetchAll()
      setDeleteTarget(null)
    } catch { toast.error('Failed to delete') }
    finally { setDeleting(false) }
  }

  if (userLoading) {
    return (
      <AdminLayout currentPath="/admin/clients" title="Client Detail">
        <div className="flex items-center justify-center py-20">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#1a56ff]" />
        </div>
      </AdminLayout>
    )
  }

  if (!user) {
    return (
      <AdminLayout currentPath="/admin/clients" title="Client Detail">
        <div className="text-center py-20 text-slate-400">User not found</div>
      </AdminLayout>
    )
  }

  const initials = (user.displayName || user.email || 'U').slice(0, 2).toUpperCase()

  return (
    <AdminLayout currentPath="/admin/clients" title="Client Detail">
      {/* Back link */}
      <Link to="/admin/clients" className="inline-flex items-center gap-2 text-sm text-slate-500 hover:text-slate-800 mb-5 transition-colors">
        <ArrowLeft size={15} /> Back to Clients
      </Link>

      {/* User card */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-5 mb-6 flex items-start gap-4">
        <div className="w-14 h-14 rounded-full bg-[#1a56ff] flex items-center justify-center text-white text-lg font-bold flex-shrink-0">
          {initials}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h2 className="text-lg font-bold text-slate-900">{user.displayName || 'No name'}</h2>
            {user.role === 'admin' ? (
              <span className="inline-flex items-center gap-1 text-xs font-semibold px-2 py-0.5 rounded-full bg-amber-50 text-amber-700 border border-amber-200">
                <Shield size={10} /> Admin
              </span>
            ) : (
              <span className="text-xs font-medium text-slate-500 px-2 py-0.5 rounded-full bg-slate-100">Client</span>
            )}
            {user.emailVerified && (
              <span className="inline-flex items-center gap-1 text-xs font-semibold px-2 py-0.5 rounded-full bg-green-50 text-green-700">
                <CheckCircle size={10} /> Verified
              </span>
            )}
          </div>
          <div className="flex flex-wrap gap-4 mt-1.5 text-sm text-slate-500">
            <span className="flex items-center gap-1.5"><Mail size={13} />{user.email}</span>
            {user.phone && <span className="flex items-center gap-1.5"><Phone size={13} />{user.phone}</span>}
            <span className="flex items-center gap-1.5"><Calendar size={13} />Joined {user.createdAt ? format(new Date(user.createdAt), 'MMM d, yyyy') : '—'}</span>
          </div>
        </div>
        <button
          onClick={() => setEditUser(true)}
          className="flex items-center gap-2 px-4 py-2 rounded-lg border border-[#1a56ff] text-[#1a56ff] text-sm font-semibold hover:bg-blue-50 transition-colors flex-shrink-0"
        >
          <Edit2 size={14} /> Edit User
        </button>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
        {[
          { icon: ShoppingBag, label: 'Orders', value: orders.length, color: 'bg-blue-50 text-[#1a56ff]' },
          { icon: Building2, label: 'Companies', value: companies.length, color: 'bg-purple-50 text-purple-600' },
          { icon: FileText, label: 'Documents', value: documents.length, color: 'bg-green-50 text-green-600' },
          { icon: CreditCard, label: 'Payments', value: payments.length, color: 'bg-amber-50 text-amber-600' },
        ].map(({ icon: Icon, label, value, color }) => (
          <div key={label} className="bg-white rounded-xl border border-slate-200 shadow-sm p-4 flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${color}`}><Icon size={18} /></div>
            <div><p className="text-xl font-bold text-slate-900">{value}</p><p className="text-xs text-slate-500">{label}</p></div>
          </div>
        ))}
      </div>

      {/* ── Orders table ── */}
      <SectionTable
        title="Orders"
        icon={<ShoppingBag size={16} className="text-[#1a56ff]" />}
        count={orders.length}
        headers={['Order #', 'Company', 'Package', 'Amount', 'Status', 'Date', 'Actions']}
        empty="No orders"
        rows={orders.map(o => (
          <tr key={o.id} className="hover:bg-slate-50 border-b border-slate-100">
            <td className="px-4 py-3 font-mono text-xs text-slate-500">#{o.orderNumber}</td>
            <td className="px-4 py-3"><p className="font-medium text-slate-900 text-sm">{o.companyName}</p><p className="text-xs text-slate-400">{o.companyState} · {o.companyType}</p></td>
            <td className="px-4 py-3 text-sm text-slate-600">{o.packageName}</td>
            <td className="px-4 py-3 font-semibold text-slate-900">${o.amount.toLocaleString()}</td>
            <td className="px-4 py-3"><StatusBadge status={o.status} /></td>
            <td className="px-4 py-3 text-xs text-slate-400">{o.createdAt ? format(new Date(o.createdAt), 'MMM d, yyyy') : '—'}</td>
            <td className="px-4 py-3">
              <div className="flex items-center gap-2">
                <button onClick={() => setEditOrder(o)} className="p-1.5 rounded-lg text-slate-400 hover:text-[#1a56ff] hover:bg-blue-50 transition-colors"><Edit2 size={14} /></button>
                <button onClick={() => setDeleteTarget({ type: 'order', id: o.id, label: `Order #${o.orderNumber}` })} className="p-1.5 rounded-lg text-slate-400 hover:text-red-500 hover:bg-red-50 transition-colors"><Trash2 size={14} /></button>
              </div>
            </td>
          </tr>
        ))}
      />

      {/* ── Companies table ── */}
      <SectionTable
        title="Companies"
        icon={<Building2 size={16} className="text-purple-600" />}
        count={companies.length}
        headers={['Name', 'Type', 'State', 'EIN', 'Status', 'Actions']}
        empty="No companies"
        rows={companies.map(c => (
          <tr key={c.id} className="hover:bg-slate-50 border-b border-slate-100">
            <td className="px-4 py-3 font-medium text-slate-900">{c.companyName}</td>
            <td className="px-4 py-3 text-sm text-slate-600">{c.companyType}</td>
            <td className="px-4 py-3 text-sm text-slate-600">{c.state}</td>
            <td className="px-4 py-3 font-mono text-xs text-slate-500">{c.einNumber || '—'}</td>
            <td className="px-4 py-3"><StatusBadge status={c.status} /></td>
            <td className="px-4 py-3">
              <div className="flex items-center gap-2">
                <button onClick={() => setEditCompany(c)} className="p-1.5 rounded-lg text-slate-400 hover:text-[#1a56ff] hover:bg-blue-50 transition-colors"><Edit2 size={14} /></button>
                <button onClick={() => setDeleteTarget({ type: 'company', id: c.id, label: c.companyName })} className="p-1.5 rounded-lg text-slate-400 hover:text-red-500 hover:bg-red-50 transition-colors"><Trash2 size={14} /></button>
              </div>
            </td>
          </tr>
        ))}
      />

      {/* ── Documents table ── */}
      <SectionTable
        title="Documents"
        icon={<FileText size={16} className="text-green-600" />}
        count={documents.length}
        headers={['Name', 'Type', 'Status', 'Created', 'Actions']}
        empty="No documents"
        action={<button onClick={() => setAddDoc(true)} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#1a56ff] text-white text-xs font-semibold hover:bg-[#1440d0] transition-colors"><Plus size={13} />Add Document</button>}
        rows={documents.map(d => (
          <tr key={d.id} className="hover:bg-slate-50 border-b border-slate-100">
            <td className="px-4 py-3 font-medium text-slate-900">{d.name}</td>
            <td className="px-4 py-3 text-xs text-slate-500">{d.docType?.replace(/_/g, ' ')}</td>
            <td className="px-4 py-3"><StatusBadge status={d.status} /></td>
            <td className="px-4 py-3 text-xs text-slate-400">{d.createdAt ? format(new Date(d.createdAt), 'MMM d, yyyy') : '—'}</td>
            <td className="px-4 py-3">
              <div className="flex items-center gap-2">
                {d.fileUrl && <a href={d.fileUrl} target="_blank" rel="noopener noreferrer" className="p-1.5 rounded-lg text-slate-400 hover:text-green-600 hover:bg-green-50 transition-colors"><ExternalLink size={14} /></a>}
                <button onClick={() => setEditDoc(d)} className="p-1.5 rounded-lg text-slate-400 hover:text-[#1a56ff] hover:bg-blue-50 transition-colors"><Edit2 size={14} /></button>
                <button onClick={() => setDeleteTarget({ type: 'document', id: d.id, label: d.name })} className="p-1.5 rounded-lg text-slate-400 hover:text-red-500 hover:bg-red-50 transition-colors"><Trash2 size={14} /></button>
              </div>
            </td>
          </tr>
        ))}
      />

      {/* ── Payments table ── */}
      <SectionTable
        title="Payments"
        icon={<CreditCard size={16} className="text-amber-600" />}
        count={payments.length}
        headers={['Invoice', 'Service', 'Amount', 'Status', 'Date', 'Actions']}
        empty="No payments"
        rows={payments.map((p: any) => (
          <tr key={p.id} className="hover:bg-slate-50 border-b border-slate-100">
            <td className="px-4 py-3 font-mono text-xs text-slate-500">{p.invoiceId}</td>
            <td className="px-4 py-3 text-sm text-slate-900">{p.service}</td>
            <td className="px-4 py-3 font-semibold text-slate-900">${Number(p.amount).toLocaleString()}</td>
            <td className="px-4 py-3"><StatusBadge status={p.status} /></td>
            <td className="px-4 py-3 text-xs text-slate-400">{p.createdAt ? format(new Date(p.createdAt), 'MMM d, yyyy') : '—'}</td>
            <td className="px-4 py-3">
              <div className="flex items-center gap-2">
                <button onClick={() => setEditPayment(p)} className="p-1.5 rounded-lg text-slate-400 hover:text-[#1a56ff] hover:bg-blue-50 transition-colors"><Edit2 size={14} /></button>
                <button onClick={() => setDeleteTarget({ type: 'payment', id: p.id, label: p.invoiceId })} className="p-1.5 rounded-lg text-slate-400 hover:text-red-500 hover:bg-red-50 transition-colors"><Trash2 size={14} /></button>
              </div>
            </td>
          </tr>
        ))}
      />

      {/* Modals */}
      {editUser && user && <EditUserDrawer user={user} onClose={() => setEditUser(false)} onSaved={refetchAll} />}
      {editOrder && <EditOrderModal order={editOrder} onClose={() => setEditOrder(null)} onSaved={refetchAll} />}
      {editCompany && <EditCompanyModal company={editCompany} onClose={() => setEditCompany(null)} onSaved={refetchAll} />}
      {editDoc && <EditDocumentModal doc={editDoc} onClose={() => setEditDoc(null)} onSaved={refetchAll} />}
      {addDoc && <AddDocumentModal userId={userId} orders={orders} companies={companies} onClose={() => setAddDoc(false)} onSaved={refetchAll} />}
      {editPayment && <EditPaymentModal payment={editPayment} onClose={() => setEditPayment(null)} onSaved={refetchAll} />}
      {deleteTarget && (
        <ConfirmDeleteModal
          label={deleteTarget.label}
          onConfirm={handleDelete}
          onCancel={() => setDeleteTarget(null)}
          loading={deleting}
        />
      )}
    </AdminLayout>
  )
}

// ── Reusable section table ─────────────────────────────────────────────────
function SectionTable({ title, icon, count, headers, rows, empty, action }: {
  title: string; icon: React.ReactNode; count: number;
  headers: string[]; rows: React.ReactNode[]; empty: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden mb-6">
      <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-100">
        <div className="flex items-center gap-2">
          {icon}
          <span className="font-semibold text-slate-900">{title}</span>
          <span className="bg-slate-100 text-slate-500 text-xs px-2 py-0.5 rounded-full">{count}</span>
        </div>
        {action}
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-100">
              {headers.map(h => (
                <th key={h} className="px-4 py-2.5 text-left text-xs font-medium text-slate-500 uppercase tracking-wide whitespace-nowrap">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 ? (
              <tr><td colSpan={headers.length} className="px-4 py-8 text-center text-sm text-slate-400">{empty}</td></tr>
            ) : rows}
          </tbody>
        </table>
      </div>
    </div>
  )
}
