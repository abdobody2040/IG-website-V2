import { useState, useMemo } from 'react'
import { Building2, Search, Edit2, Trash2, X, Loader2 } from 'lucide-react'
import { useQueryClient } from '@tanstack/react-query'
import AdminLayout from './AdminLayout'
import { useAllCompanies } from '../../hooks/useAdminData'
import { useRequireAdmin } from '../../hooks/useRequireAuth'
import { supabase } from '../../lib/supabase'
import toast from 'react-hot-toast'
import type { Company } from '../../types/db'

const COMPANY_STATUS_OPTIONS = [
  { value: 'pending', label: 'Pending' },
  { value: 'active', label: 'Active' },
  { value: 'suspended', label: 'Suspended' },
  { value: 'completed', label: 'Completed' },
]

const STATUS_COLORS: Record<string, string> = {
  pending: 'bg-amber-100 text-amber-700',
  active: 'bg-green-100 text-green-700',
  completed: 'bg-green-100 text-green-700',
  suspended: 'bg-red-100 text-red-700',
}

function StatusBadge({ status }: { status: string }) {
  const cls = STATUS_COLORS[status] ?? 'bg-slate-100 text-slate-600'
  const label = COMPANY_STATUS_OPTIONS.find(o => o.value === status)?.label ?? status
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${cls}`}>
      {label}
    </span>
  )
}

// ── Delete Confirm Modal ─────────────────────────────────────────
function DeleteConfirmModal({
  company,
  onConfirm,
  onClose,
  loading,
}: {
  company: Company
  onConfirm: () => void
  onClose: () => void
  loading: boolean
}) {
  return (
    <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-xl w-full max-w-sm p-6">
        <div className="flex items-start gap-3 mb-4">
          <div className="w-10 h-10 rounded-full bg-red-100 flex items-center justify-center flex-shrink-0">
            <Trash2 size={18} className="text-red-600" />
          </div>
          <div>
            <h3 className="font-semibold text-slate-900 text-sm">Delete Company</h3>
            <p className="text-sm text-slate-500 mt-1">
              Are you sure you want to delete <span className="font-medium text-slate-700">{company.companyName}</span>? This cannot be undone.
            </p>
          </div>
        </div>
        <div className="flex gap-2 justify-end">
          <button
            onClick={onClose}
            disabled={loading}
            className="px-4 py-2 text-sm rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors disabled:opacity-50"
          >
            Cancel
          </button>
          <button
            onClick={onConfirm}
            disabled={loading}
            className="px-4 py-2 text-sm rounded-lg bg-red-500 text-white font-medium hover:bg-red-600 transition-colors disabled:opacity-50 flex items-center gap-1.5"
          >
            {loading && <Loader2 size={13} className="animate-spin" />}
            Delete
          </button>
        </div>
      </div>
    </div>
  )
}

// ── Edit Company Modal ────────────────────────────────────────────
function EditCompanyModal({
  company,
  onClose,
  onSaved,
}: {
  company: Company
  onClose: () => void
  onSaved: () => void
}) {
  const [companyName, setCompanyName] = useState(company.companyName || '')
  const [companyType, setCompanyType] = useState(company.companyType || 'LLC')
  const [state, setState] = useState(company.state || '')
  const [einNumber, setEinNumber] = useState(company.einNumber || '')
  const [formationDate, setFormationDate] = useState(company.formationDate || '')
  const [registeredAgent, setRegisteredAgent] = useState(company.registeredAgent || '')
  const [status, setStatus] = useState(company.status || 'pending')
  const [saving, setSaving] = useState(false)

  const handleSave = async () => {
    setSaving(true)
    try {
      const { error: updateErr } = await supabase.from('companies').update({
        company_name: companyName,
        company_type: companyType,
        state,
        ein_number: einNumber,
        formation_date: formationDate,
        registered_agent: registeredAgent,
        status,
        updated_at: new Date().toISOString(),
      }).eq('id', company.id)
      if (updateErr) throw updateErr
      toast.success('Company updated successfully')
      onSaved()
    } catch {
      toast.error('Failed to update company')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-xl w-full max-w-lg max-h-[90vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 flex-shrink-0">
          <div>
            <h2 className="font-semibold text-slate-900">Edit Company</h2>
            <p className="text-xs text-slate-500 mt-0.5">{company.companyName}</p>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-700 transition-colors">
            <X size={20} />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto px-6 py-5 space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2">
              <label className="block text-xs font-medium text-slate-600 mb-1">Company Name</label>
              <input
                value={companyName}
                onChange={e => setCompanyName(e.target.value)}
                className="w-full text-sm border border-slate-200 rounded-lg px-3 py-2 focus:outline-none focus:border-[#1a56ff] bg-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">Company Type</label>
              <select
                value={companyType}
                onChange={e => setCompanyType(e.target.value)}
                className="w-full text-sm border border-slate-200 rounded-lg px-3 py-2 focus:outline-none focus:border-[#1a56ff] bg-white"
              >
                <option value="LLC">LLC</option>
                <option value="LTD">LTD</option>
                <option value="C-Corp">C-Corp</option>
                <option value="S-Corp">S-Corp</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">State</label>
              <input
                value={state}
                onChange={e => setState(e.target.value)}
                className="w-full text-sm border border-slate-200 rounded-lg px-3 py-2 focus:outline-none focus:border-[#1a56ff] bg-white"
                placeholder="e.g. Delaware"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">EIN Number</label>
              <input
                value={einNumber}
                onChange={e => setEinNumber(e.target.value)}
                className="w-full text-sm border border-slate-200 rounded-lg px-3 py-2 focus:outline-none focus:border-[#1a56ff] bg-white"
                placeholder="XX-XXXXXXX"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">Formation Date</label>
              <input
                value={formationDate}
                onChange={e => setFormationDate(e.target.value)}
                type="date"
                className="w-full text-sm border border-slate-200 rounded-lg px-3 py-2 focus:outline-none focus:border-[#1a56ff] bg-white"
              />
            </div>
            <div className="col-span-2">
              <label className="block text-xs font-medium text-slate-600 mb-1">Registered Agent</label>
              <input
                value={registeredAgent}
                onChange={e => setRegisteredAgent(e.target.value)}
                className="w-full text-sm border border-slate-200 rounded-lg px-3 py-2 focus:outline-none focus:border-[#1a56ff] bg-white"
                placeholder="Agent name or company"
              />
            </div>
            <div className="col-span-2">
              <label className="block text-xs font-medium text-slate-600 mb-1">Status</label>
              <select
                value={status}
                onChange={e => setStatus(e.target.value)}
                className="w-full text-sm border border-slate-200 rounded-lg px-3 py-2 focus:outline-none focus:border-[#1a56ff] bg-white"
              >
                {COMPANY_STATUS_OPTIONS.map(opt => (
                  <option key={opt.value} value={opt.value}>{opt.label}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Read-only fields */}
          <div className="p-3 bg-slate-50 rounded-lg space-y-1.5">
            <p className="text-xs font-medium text-slate-500 uppercase tracking-wide mb-2">System Fields (read-only)</p>
            <div className="flex justify-between text-xs">
              <span className="text-slate-500">Company ID</span>
              <span className="text-slate-700 font-mono">{company.id.slice(0, 16)}…</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-slate-500">Order ID</span>
              <span className="text-slate-700 font-mono">{company.orderId ? `${company.orderId.slice(0, 16)}…` : '—'}</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-slate-500">User ID</span>
              <span className="text-slate-700 font-mono">{company.userId ? `${company.userId.slice(0, 16)}…` : '—'}</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-slate-500">Created</span>
              <span className="text-slate-700">{new Date(company.createdAt).toLocaleDateString()}</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center gap-2 px-6 py-4 border-t border-slate-200 flex-shrink-0">
          <button
            onClick={onClose}
            className="flex-1 py-2 text-sm rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={saving}
            className="flex-1 py-2 text-sm rounded-lg bg-[#1a56ff] text-white font-medium hover:bg-blue-700 transition-colors disabled:opacity-50 flex items-center justify-center gap-1.5"
          >
            {saving && <Loader2 size={13} className="animate-spin" />}
            Save Changes
          </button>
        </div>
      </div>
    </div>
  )
}

// ── Main Page ─────────────────────────────────────────────────────
export default function AdminCompaniesPage() {
  const { isLoading: authLoading } = useRequireAdmin()
  const { companies, isLoading } = useAllCompanies()
  const queryClient = useQueryClient()

  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')
  const [editingCompany, setEditingCompany] = useState<Company | null>(null)
  const [deletingCompany, setDeletingCompany] = useState<Company | null>(null)
  const [deleteLoading, setDeleteLoading] = useState(false)

  const filtered = useMemo(() => {
    return companies.filter(c => {
      const q = search.toLowerCase()
      const matchSearch = !search || c.companyName?.toLowerCase().includes(q)
      const matchStatus = statusFilter === 'all' || c.status === statusFilter
      return matchSearch && matchStatus
    })
  }, [companies, search, statusFilter])

  if (authLoading) return <div className="flex items-center justify-center h-screen"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#1a56ff]" /></div>

  const handleDelete = async () => {
    if (!deletingCompany) return
    setDeleteLoading(true)
    try {
      const { error: delErr } = await supabase.from('companies').delete().eq('id', deletingCompany.id)
      if (delErr) throw delErr
      await queryClient.invalidateQueries({ queryKey: ['admin', 'companies'] })
      toast.success('Company deleted')
      setDeletingCompany(null)
    } catch {
      toast.error('Failed to delete company')
    } finally {
      setDeleteLoading(false)
    }
  }

  const handleSaved = async () => {
    await queryClient.invalidateQueries({ queryKey: ['admin', 'companies'] })
    setEditingCompany(null)
  }

  return (
    <AdminLayout currentPath="/admin/companies" title="Companies">
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-0.5">
          <Building2 className="h-5 w-5 text-[#1a56ff]" />
          <h2 className="text-xl font-bold text-slate-900">All Companies</h2>
          <span className="bg-slate-100 text-slate-600 text-xs font-medium px-2 py-0.5 rounded-full">{companies.length}</span>
        </div>
        <p className="text-slate-500 text-sm mt-0.5">Manage registered companies and their formation details</p>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3 mb-4">
        <div className="relative">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search by company name"
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-9 pr-4 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-[#1a56ff] bg-white w-64"
          />
        </div>
        <select
          value={statusFilter}
          onChange={e => setStatusFilter(e.target.value)}
          className="py-2 px-3 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-[#1a56ff] bg-white"
        >
          <option value="all">All Statuses</option>
          {COMPANY_STATUS_OPTIONS.map(opt => (
            <option key={opt.value} value={opt.value}>{opt.label}</option>
          ))}
        </select>
        <span className="py-2 text-sm text-slate-500">{filtered.length} compan{filtered.length !== 1 ? 'ies' : 'y'}</span>
      </div>

      {/* Table */}
      {isLoading ? (
        <div className="flex items-center gap-3 py-12 justify-center">
          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-[#1a56ff]" />
          <span className="text-slate-500 text-sm">Loading companies…</span>
        </div>
      ) : filtered.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-12 text-center">
          <Building2 size={36} className="text-slate-300 mx-auto mb-3" />
          <p className="text-slate-500 text-sm">No companies found</p>
        </div>
      ) : (
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm min-w-[1000px]">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50 text-xs text-slate-500 uppercase">
                  {['Company', 'Type', 'State', 'EIN', 'Formation Date', 'Reg. Agent', 'Status', 'User ID', 'Actions'].map(h => (
                    <th key={h} className="px-5 py-3 text-left font-medium">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filtered.map(company => (
                  <tr key={company.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-5 py-3">
                      <p className="font-medium text-slate-900">{company.companyName}</p>
                      <p className="text-xs text-slate-400 font-mono">{company.id.slice(0, 10)}…</p>
                    </td>
                    <td className="px-5 py-3 text-slate-600 text-xs font-medium">{company.companyType || '—'}</td>
                    <td className="px-5 py-3 text-slate-600 text-xs">{company.state || '—'}</td>
                    <td className="px-5 py-3 text-slate-600 text-xs font-mono">{company.einNumber || '—'}</td>
                    <td className="px-5 py-3 text-slate-500 text-xs whitespace-nowrap">
                      {company.formationDate ? new Date(company.formationDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : '—'}
                    </td>
                    <td className="px-5 py-3 text-slate-600 text-xs max-w-[100px] truncate">{company.registeredAgent || '—'}</td>
                    <td className="px-5 py-3">
                      <StatusBadge status={company.status} />
                    </td>
                    <td className="px-5 py-3 text-slate-400 text-xs font-mono">
                      {company.userId ? `${company.userId.slice(0, 8)}…` : '—'}
                    </td>
                    <td className="px-5 py-3">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => setEditingCompany(company)}
                          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium border border-slate-200 text-slate-600 rounded-lg hover:bg-slate-50 hover:border-slate-300 transition-colors"
                        >
                          <Edit2 size={12} /> Edit
                        </button>
                        <button
                          onClick={() => setDeletingCompany(company)}
                          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium border border-red-200 text-red-600 rounded-lg hover:bg-red-50 transition-colors"
                        >
                          <Trash2 size={12} /> Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Edit Modal */}
      {editingCompany && (
        <EditCompanyModal
          company={editingCompany}
          onClose={() => setEditingCompany(null)}
          onSaved={handleSaved}
        />
      )}

      {/* Delete Confirm */}
      {deletingCompany && (
        <DeleteConfirmModal
          company={deletingCompany}
          onConfirm={handleDelete}
          onClose={() => setDeletingCompany(null)}
          loading={deleteLoading}
        />
      )}
    </AdminLayout>
  )
}
