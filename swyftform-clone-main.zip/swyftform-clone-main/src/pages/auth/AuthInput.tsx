/**
 * AuthInput — Reusable styled input for auth forms.
 */
import { forwardRef, InputHTMLAttributes } from 'react'

interface AuthInputProps extends InputHTMLAttributes<HTMLInputElement> {
  label: string
  error?: string
}

export const AuthInput = forwardRef<HTMLInputElement, AuthInputProps>(
  ({ label, error, id, ...props }, ref) => {
    const inputId = id ?? label.toLowerCase().replace(/\s+/g, '-')
    return (
      <div className="space-y-1.5">
        <label htmlFor={inputId} className="block text-sm font-medium text-slate-700">
          {label}
        </label>
        <input
          ref={ref}
          id={inputId}
          className={[
            'w-full rounded-xl border px-4 py-3 text-sm text-slate-900 placeholder-slate-400',
            'bg-white outline-none transition-all duration-200',
            'focus:ring-2 focus:ring-offset-0',
            error
              ? 'border-red-400 focus:ring-red-200'
              : 'border-slate-200 focus:border-blue-500 focus:ring-blue-100',
          ].join(' ')}
          style={{ fontFamily: 'Inter, sans-serif' }}
          {...props}
        />
        {error && <p className="text-xs text-red-500 mt-1">{error}</p>}
      </div>
    )
  }
)

AuthInput.displayName = 'AuthInput'
