import { useState } from 'react'
import { useNavigate, useSearch } from '@tanstack/react-router'
import { useForm } from 'react-hook-form'
import {
  Check, ChevronRight, ChevronLeft, Building2, Globe, Package, User, ArrowLeft, ArrowRight,
  Plus, Trash2, CreditCard, ShieldCheck, Zap
} from 'lucide-react'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../hooks/useAuth'
import { toast } from 'react-hot-toast'
import { sendOrderConfirmationEmail } from '../../hooks/useEmailNotifications'
import { useLang } from '../../i18n/LanguageContext'

/* ── Plan catalogue ────────────────────────────────────────────────────── */
interface Plan {
  id: string
  region: 'us' | 'uk'
  name: string
  price: number
  currency: string
  label: string
  description: string
  features: string[]
  flag: string
}

const PLANS: Plan[] = [
  {
    id: 'us-basic',
    region: 'us',
    name: 'US LLC Basic',
    price: 229,
    currency: 'USD',
    label: 'Basic',
    description: 'Everything you need to launch your US LLC',
    flag: '🇺🇸',
    features: ['Wyoming LLC formation', 'Registered Agent – first year', 'EIN (US Tax ID)', 'All formation documents', 'BOI report filing', 'Stripe bank account guidance'],
  },
  {
    id: 'us-premium',
    region: 'us',
    name: 'US LLC Premium',
    price: 349,
    currency: 'USD',
    label: 'Premium',
    description: 'The complete package with full support',
    flag: '🇺🇸',
    features: ['Everything in Basic', 'Priority processing', 'Virtual US phone number', 'Custom Operating Agreement', 'Mercury/Relay account setup', 'WhatsApp + phone support', '30-min onboarding call'],
  },
  {
    id: 'uk-basic',
    region: 'uk',
    name: 'UK LTD Basic',
    price: 379,
    currency: 'USD',
    label: 'Basic',
    description: 'Everything you need to launch your UK company',
    flag: '🇬🇧',
    features: ['UK LTD (Companies House)', 'Registered office – first year', 'Certificate of Incorporation', 'All company documents', 'Wise business account referral', 'Stripe UK setup guidance'],
  },
  {
    id: 'uk-premium',
    region: 'uk',
    name: 'UK LTD Premium',
    price: 499,
    currency: 'USD',
    label: 'Premium',
    description: 'The complete package with full support',
    flag: '🇬🇧',
    features: ["Everything in Basic", "Director's service address", 'Virtual UK phone number', 'First Confirmation Statement', 'Full Wise account setup', 'WhatsApp + phone support', '30-min onboarding call'],
  },
]

/* ── US States with fees ─────────────────────────────────────────────── */
const POPULAR_STATES = [
  { name: 'New Mexico', fee: 0, note: 'No state taxes, great for privacy' },
  { name: 'Wyoming', fee: 50, note: 'No state taxes, strong asset protection' },
  { name: 'Delaware', fee: 100, note: 'Best for corporations, business-friendly courts' },
]

const ALL_US_STATES = [
  'Alabama','Alaska','Arizona','Arkansas','California','Colorado','Connecticut',
  'Florida','Georgia','Hawaii','Idaho','Illinois','Indiana','Iowa','Kansas','Kentucky',
  'Louisiana','Maine','Maryland','Massachusetts','Michigan','Minnesota','Mississippi',
  'Missouri','Montana','Nebraska','Nevada','New Hampshire','New Jersey',
  'New York','North Carolina','North Dakota','Ohio','Oklahoma','Oregon','Pennsylvania',
  'Rhode Island','South Carolina','South Dakota','Tennessee','Texas','Utah','Vermont',
  'Virginia','Washington','West Virginia','Wisconsin',
].filter(s => !POPULAR_STATES.map(p => p.name).includes(s))

/* ── Add-ons ─────────────────────────────────────────────────────────── */
interface AddOn {
  id: string
  name: string
  description: string
  price: number
  icon: React.ReactNode
}

const ADD_ONS: AddOn[] = [
  { id: 'website', name: 'Professional Website Design', description: 'Custom business website to establish your online presence', price: 99, icon: <Globe size={16} /> },
  { id: 'logo', name: 'Custom Logo Design', description: 'Professional logo design for your brand', price: 49, icon: <ShieldCheck size={16} /> },
  { id: 'express', name: 'Express Filing', description: 'Rush processing (2–3 business days)', price: 50, icon: <Zap size={16} /> },
]

/* ── Member types ────────────────────────────────────────────────────── */
type MemberRole = 'managing_member' | 'member' | 'manager'

interface Member {
  id: string
  fullName: string
  role: MemberRole
  ownership: number
  address: string
  email: string
  phone: string
}

/* ── Step types ─────────────────────────────────────────────────────────── */
interface Step1Data { planId: string }
interface Step2Data { companyName: string; companyState: string; companyType: string; businessPurpose: string }
interface Step3Data { fullName: string; email: string; phone?: string; whatsapp?: string }

type WizardData = Step1Data & Step2Data & Step3Data

const STEPS = [
  { label: 'Company Info', icon: Building2 },
  { label: 'Owner Info', icon: User },
  { label: 'Service Package', icon: Package },
  { label: 'Add-ons', icon: Plus },
  { label: 'Account', icon: User },
  { label: 'Review & Pay', icon: CreditCard },
]

/* ── Step Indicator ─────────────────────────────────────────────────── */
function StepIndicator({ current }: { current: number }) {
  const { t } = useLang()
  return (
    <div className="flex items-center justify-center gap-0 mb-8 overflow-x-auto pb-2">
      {STEPS.map((step, i) => {
        const Icon = step.icon
        const done = i < current
        const active = i === current
        return (
          <div key={i} className="flex items-center">
            <div className="flex flex-col items-center gap-1 min-w-[60px]">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center transition-all border-2 ${
                done
                  ? 'bg-[#1a56ff] border-[#1a56ff] text-white'
                  : active
                  ? 'bg-[#1a56ff] border-[#1a56ff] text-white ring-4 ring-[#1a56ff]/20'
                  : 'bg-white border-slate-300 text-slate-400'
              }`}>
                {done ? <Check size={14} /> : <span className="text-xs font-bold">{i + 1}</span>}
              </div>
              <span className={`text-[9px] font-semibold text-center leading-tight hidden sm:block ${
                active ? 'text-[#1a56ff]' : done ? 'text-slate-600' : 'text-slate-400'
              }`}>
                {t.order.stepLabels[i]}
              </span>
            </div>
            {i < STEPS.length - 1 && (
              <div className={`h-0.5 w-6 sm:w-10 mb-4 flex-shrink-0 ${done ? 'bg-[#1a56ff]' : 'bg-slate-200'}`} />
            )}
          </div>
        )
      })}
    </div>
  )
}

/* ── Order Summary Sidebar ──────────────────────────────────────────── */
function OrderSummary({
  plan, stateFee, addOns, selectedAddOns
}: {
  plan: Plan | undefined
  stateFee: number
  addOns: string[]
  selectedAddOns: AddOn[]
}) {
  const { t } = useLang()
  if (!plan) return null
  const addOnTotal = selectedAddOns.reduce((s, a) => s + a.price, 0)
  const total = plan.price + stateFee + addOnTotal
  const planT = t.order.plans[plan.id]

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5 sticky top-6">
      <p className="text-sm font-bold text-slate-900 mb-4">{t.order.orderSummary}</p>
      <div className="space-y-2 text-sm">
        <div className="flex justify-between">
          <span className="text-slate-600">{t.order.basePackage}</span>
          <span className="font-semibold">${plan.price}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-slate-600">{t.order.stateFeeLabel}</span>
          <span className="font-semibold">${stateFee}</span>
        </div>
        {selectedAddOns.map(a => (
          <div key={a.id} className="flex justify-between text-xs">
            <span className="text-slate-500">{t.order.addOns[a.id]?.name ?? a.name}</span>
            <span className="font-semibold">${a.price}</span>
          </div>
        ))}
      </div>
      <div className="border-t border-slate-100 mt-3 pt-3 flex justify-between items-center">
        <span className="font-bold text-slate-900">{t.order.total}</span>
        <span className="text-xl font-extrabold text-[#1a56ff]">${total}</span>
      </div>
      {plan && (
        <div className="mt-4 bg-blue-50 rounded-xl p-3">
          <p className="text-xs font-bold text-blue-800">{planT?.label ?? plan.label} {t.order.formation}</p>
          <p className="text-xs text-blue-600">{planT?.name ?? plan.name}</p>
        </div>
      )}
    </div>
  )
}

/* ── Step 1 — Company Info ───────────────────────────────────────────── */
function StepCompanyInfo({
  register, errors, planId, setPlanId, onStateFeeChange
}: {
  register: ReturnType<typeof useForm<WizardData>>['register']
  errors: ReturnType<typeof useForm<WizardData>>['formState']['errors']
  planId: string
  setPlanId: (id: string) => void
  onStateFeeChange: (fee: number) => void
}) {
  const { t } = useLang()
  const isUk = planId.startsWith('uk')
  const [selectedState, setSelectedState] = useState('')
  const [showAllStates, setShowAllStates] = useState(false)

  const handleStateSelect = (stateName: string, fee: number) => {
    setSelectedState(stateName)
    onStateFeeChange(fee)
  }

  return (
    <div>
      <h2 className="text-2xl font-bold text-slate-900 mb-1">{t.order.companyInfoTitle}</h2>
      <p className="text-slate-500 text-sm mb-6">{t.order.companyInfoDesc}</p>

      <div className="space-y-5">
        {/* Company Name */}
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-1.5">
            {t.order.companyNameLabel} <span className="text-red-500">*</span>
          </label>
          <input
            {...register('companyName', { required: t.order.companyNameRequired })}
            placeholder={isUk ? t.order.companyNamePlaceholderLTD : t.order.companyNamePlaceholderLLC}
            className="w-full bg-white text-slate-900 border border-slate-300 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-[#1a56ff] focus:ring-2 focus:ring-[#1a56ff]/10 transition-all placeholder:text-slate-400"
          />
          {errors.companyName && <p className="text-red-500 text-xs mt-1">{errors.companyName.message}</p>}
        </div>

        {/* Company Type toggle (US/UK) */}
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">{t.order.companyTypeLabel}</label>
          <div className="flex gap-3">
            {(['us', 'uk'] as const).map(r => {
              const usePlan = r === 'us' ? (planId === 'us-premium' ? 'us-premium' : 'us-basic') : (planId === 'uk-premium' ? 'uk-premium' : 'uk-basic')
              const active = planId.startsWith(r)
              return (
                <button
                  key={r}
                  type="button"
                  onClick={() => setPlanId(usePlan)}
                  className={`flex-1 py-2.5 px-4 rounded-xl border-2 text-sm font-semibold transition-all ${
                    active ? 'border-[#1a56ff] bg-[#1a56ff]/5 text-[#1a56ff]' : 'border-slate-200 text-slate-600 hover:border-[#1a56ff]/30'
                  }`}
                >
                  {r === 'us' ? '🇺🇸 LLC' : '🇬🇧 LTD'}
                </button>
              )
            })}
          </div>
        </div>

        {/* Business Purpose */}
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-1.5">
            {t.order.businessPurposeLabel}
            <span className="text-slate-400 font-normal ms-2 text-xs">{t.order.businessPurposeWords}</span>
          </label>
          <textarea
            {...register('businessPurpose')}
            placeholder={t.order.businessPurposePlaceholder}
            rows={3}
            className="w-full border border-slate-300 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-[#1a56ff] focus:ring-2 focus:ring-[#1a56ff]/10 transition-all resize-none"
          />
        </div>

        {/* Formation State (US only) */}
        {!isUk && (
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">
              {t.order.formationStateLabel} <span className="text-red-500">*</span>
            </label>
            <p className="text-xs font-semibold text-[#1a56ff] mb-2">{t.order.popularChoices}</p>
            <div className="space-y-2 mb-3">
              {POPULAR_STATES.map(s => (
                <label
                  key={s.name}
                  className={`flex items-center justify-between p-3 rounded-xl border-2 cursor-pointer transition-all ${
                    selectedState === s.name
                      ? 'border-[#1a56ff] bg-[#1a56ff]/5'
                      : 'border-slate-200 hover:border-[#1a56ff]/30'
                  }`}
                  onClick={() => handleStateSelect(s.name, s.fee)}
                >
                  <div>
                    <p className="text-sm font-semibold text-slate-900">
                      {s.name}
                      {s.fee > 0 && <span className="ms-2 text-xs text-slate-500">+${s.fee}</span>}
                      {s.fee === 0 && <span className="ms-2 text-xs text-green-600">{t.order.free}</span>}
                    </p>
                    <p className="text-xs text-slate-500">{t.order.stateNotes[s.name] ?? s.note}</p>
                  </div>
                  <div className={`w-4 h-4 rounded-full border-2 flex-shrink-0 transition-all ${
                    selectedState === s.name ? 'border-[#1a56ff] bg-[#1a56ff]' : 'border-slate-300'
                  }`}>
                    {selectedState === s.name && <Check size={10} className="text-white m-auto mt-0.5" />}
                  </div>
                </label>
              ))}
            </div>

            <button
              type="button"
              onClick={() => setShowAllStates(!showAllStates)}
              className="text-xs text-[#1a56ff] font-semibold underline mb-2"
            >
              {showAllStates ? t.order.hide : t.order.allStates}
            </button>

            {showAllStates && (
              <select
                {...register('companyState', { required: 'Please select a state' })}
                className="w-full border border-slate-300 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-[#1a56ff] bg-white"
                onChange={e => {
                  const val = e.target.value
                  setSelectedState(val)
                  onStateFeeChange(0)
                }}
              >
                <option value="">{t.order.selectState}</option>
                {ALL_US_STATES.map(s => (
                  <option key={s} value={s}>{s}</option>
                ))}
              </select>
            )}

            {/* hidden input for popular state selection */}
            <input type="hidden" {...register('companyState', { required: t.order.selectStateRequired })} value={selectedState} />
            {errors.companyState && <p className="text-red-500 text-xs mt-1">{errors.companyState.message}</p>}
          </div>
        )}
      </div>
    </div>
  )
}

/* ── Step 2 — Member Information ────────────────────────────────────── */
function StepMemberInfo({
  members, setMembers
}: {
  members: Member[]
  setMembers: (m: Member[]) => void
}) {
  const { t } = useLang()
  const totalOwnership = members.reduce((s, m) => s + (m.ownership || 0), 0)
  const isComplete = totalOwnership === 100

  const updateMember = (id: string, field: keyof Member, value: string | number) => {
    setMembers(members.map(m => m.id === id ? { ...m, [field]: value } : m))
  }

  const addMember = () => {
    setMembers([...members, {
      id: crypto.randomUUID(),
      fullName: '',
      role: 'member',
      ownership: 0,
      address: '',
      email: '',
      phone: ''
    }])
  }

  const removeMember = (id: string) => {
    if (members.length <= 1) return
    setMembers(members.filter(m => m.id !== id))
  }

  const ROLES: { value: MemberRole; label: string; desc: string }[] = [
    { value: 'managing_member', label: t.order.roles.managing_member.label, desc: t.order.roles.managing_member.desc },
    { value: 'member', label: t.order.roles.member.label, desc: t.order.roles.member.desc },
    { value: 'manager', label: t.order.roles.manager.label, desc: t.order.roles.manager.desc },
  ]

  return (
    <div>
      <h2 className="text-2xl font-bold text-slate-900 mb-1">{t.order.memberInfoTitle}</h2>
      <p className="text-slate-500 text-sm mb-4">{t.order.memberInfoDesc}</p>

      {/* Ownership tracker */}
      <div className={`rounded-xl px-4 py-2.5 text-sm font-semibold mb-5 flex items-center justify-between ${
        isComplete ? 'bg-green-50 border border-green-200 text-green-700' : 'bg-blue-50 border border-blue-200 text-blue-700'
      }`}>
        <span>{t.order.totalOwnership}: {totalOwnership.toFixed(1)}%</span>
        {isComplete && <span className="text-xs">✓ {t.order.completeLabel}</span>}
      </div>

      <div className="space-y-5">
        {members.map((member, idx) => (
          <div key={member.id} className="border border-slate-200 rounded-2xl p-5 relative">
            <div className="flex items-center justify-between mb-4">
              <p className="text-sm font-bold text-slate-900">{t.order.memberLabel} {idx + 1}</p>
              {members.length > 1 && (
                <button
                  type="button"
                  onClick={() => removeMember(member.id)}
                  className="text-red-400 hover:text-red-600 transition-colors"
                >
                  <Trash2 size={15} />
                </button>
              )}
            </div>

            <div className="space-y-3">
              {/* Full Name */}
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">{t.order.fullNameLabel} <span className="text-red-500">*</span></label>
                <input
                  value={member.fullName}
                  onChange={e => updateMember(member.id, 'fullName', e.target.value)}
                  placeholder={t.order.fullNamePlaceholder}
                  className="w-full border border-slate-300 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-[#1a56ff] focus:ring-2 focus:ring-[#1a56ff]/10"
                />
              </div>

              {/* Role */}
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-2">{t.order.roleLabel}</label>
                <div className="grid grid-cols-3 gap-2">
                  {ROLES.map(role => (
                    <button
                      key={role.value}
                      type="button"
                      onClick={() => updateMember(member.id, 'role', role.value)}
                      className={`p-2.5 rounded-xl border-2 text-left transition-all ${
                        member.role === role.value
                          ? 'border-[#1a56ff] bg-[#1a56ff]/5'
                          : 'border-slate-200 hover:border-[#1a56ff]/30'
                      }`}
                    >
                      <p className={`text-xs font-bold leading-tight ${member.role === role.value ? 'text-[#1a56ff]' : 'text-slate-700'}`}>
                        {role.label}
                      </p>
                      <p className="text-[9px] text-slate-400 mt-0.5 leading-tight">{role.desc}</p>
                    </button>
                  ))}
                </div>
              </div>

              {/* Ownership */}
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">{t.order.ownershipLabel} <span className="text-red-500">*</span></label>
                <input
                  type="number"
                  min={0}
                  max={100}
                  value={member.ownership || ''}
                  onChange={e => updateMember(member.id, 'ownership', parseFloat(e.target.value) || 0)}
                  placeholder="50"
                  className="w-full border border-slate-300 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-[#1a56ff] focus:ring-2 focus:ring-[#1a56ff]/10"
                />
              </div>

              {/* Address */}
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">{t.order.addressLabel} <span className="text-red-500">*</span></label>
                <input
                  value={member.address}
                  onChange={e => updateMember(member.id, 'address', e.target.value)}
                  placeholder={t.order.addressPlaceholder}
                  className="w-full border border-slate-300 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-[#1a56ff] focus:ring-2 focus:ring-[#1a56ff]/10"
                />
              </div>

              {/* Email */}
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">{t.order.emailLabel} <span className="text-red-500">*</span></label>
                <input
                  type="email"
                  value={member.email}
                  onChange={e => updateMember(member.id, 'email', e.target.value)}
                  placeholder={t.order.emailPlaceholder}
                  className="w-full border border-slate-300 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-[#1a56ff] focus:ring-2 focus:ring-[#1a56ff]/10"
                />
              </div>

              {/* Phone */}
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">{t.order.phoneLabel} <span className="text-red-500">*</span></label>
                <input
                  value={member.phone}
                  onChange={e => updateMember(member.id, 'phone', e.target.value)}
                  placeholder={t.order.phonePlaceholder}
                  className="w-full border border-slate-300 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-[#1a56ff] focus:ring-2 focus:ring-[#1a56ff]/10"
                />
              </div>
            </div>
          </div>
        ))}
      </div>

      <button
        type="button"
        onClick={addMember}
        className="mt-4 w-full flex items-center justify-center gap-2 border-2 border-dashed border-slate-300 rounded-2xl py-3 text-sm font-semibold text-slate-500 hover:border-[#1a56ff] hover:text-[#1a56ff] transition-colors"
      >
        <Plus size={15} /> {t.order.addAnotherMember}
      </button>
    </div>
  )
}

/* ── Step 3 — Service Package ────────────────────────────────────────── */
function StepServicePackage({
  planId, setPlanId
}: {
  planId: string
  setPlanId: (id: string) => void
}) {
  const { t } = useLang()
  const isUk = planId.startsWith('uk')
  const filtered = PLANS.filter(p => p.region === (isUk ? 'uk' : 'us'))

  return (
    <div>
      <h2 className="text-2xl font-bold text-slate-900 mb-1">{t.order.servicePackageTitle}</h2>
      <p className="text-slate-500 text-sm mb-6">{t.order.servicePackageDesc}</p>

      <div className="grid sm:grid-cols-2 gap-4">
        {filtered.map(plan => {
          const selected = planId === plan.id
          return (
            <button
              key={plan.id}
              type="button"
              onClick={() => setPlanId(plan.id)}
              className={`text-left p-5 rounded-2xl border-2 transition-all hover:shadow-md ${
                selected ? 'border-[#1a56ff] bg-[#1a56ff]/5 shadow-md' : 'border-slate-200 bg-white hover:border-[#1a56ff]/30'
              }`}
            >
              <div className="flex items-start justify-between mb-3">
                <div>
                  <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">{t.order.plans[plan.id]?.label ?? plan.label}</span>
                  <p className="font-bold text-slate-900 text-lg">{plan.flag} {t.order.plans[plan.id]?.name ?? plan.name}</p>
                </div>
                <div className={`w-5 h-5 rounded-full border-2 flex-shrink-0 mt-1 transition-all ${
                  selected ? 'border-[#1a56ff] bg-[#1a56ff]' : 'border-slate-300'
                }`}>
                  {selected && <Check size={12} className="text-white m-auto mt-0.5" />}
                </div>
              </div>
              <p className="text-2xl font-extrabold text-[#0a0f1e] mb-1">${plan.price}</p>
              <p className="text-xs text-slate-400 mb-3">{t.order.oneTimePayment}</p>
              <ul className="space-y-1.5">
                {(t.order.plans[plan.id]?.features ?? plan.features).slice(0, 4).map((f: string, i: number) => (
                  <li key={i} className="flex items-start gap-2 text-xs text-slate-600">
                    <Check size={11} className="text-[#1a56ff] flex-shrink-0 mt-0.5" />
                    {f}
                  </li>
                ))}
                {plan.features.length > 4 && (
                  <li className="text-xs text-[#1a56ff] font-medium">+{plan.features.length - 4} {t.order.moreIncluded}</li>
                )}
              </ul>
            </button>
          )
        })}
      </div>
    </div>
  )
}

/* ── Step 4 — Add-ons ────────────────────────────────────────────────── */
function StepAddOns({
  selectedAddOns, setSelectedAddOns
}: {
  selectedAddOns: string[]
  setSelectedAddOns: (ids: string[]) => void
}) {
  const { t } = useLang()
  const toggle = (id: string) => {
    setSelectedAddOns(
      selectedAddOns.includes(id)
        ? selectedAddOns.filter(a => a !== id)
        : [...selectedAddOns, id]
    )
  }

  return (
    <div>
      <h2 className="text-2xl font-bold text-slate-900 mb-1">{t.order.addOnServicesTitle}</h2>
      <p className="text-slate-500 text-sm mb-4">{t.order.addOnServicesDesc}</p>

      <p className="text-xs font-bold text-[#1a56ff] mb-3">{t.order.premiumAddOns}</p>

      <div className="space-y-3">
        {ADD_ONS.map(addon => {
          const checked = selectedAddOns.includes(addon.id)
          return (
            <label
              key={addon.id}
              className={`flex items-center justify-between p-4 rounded-xl border-2 cursor-pointer transition-all ${
                checked ? 'border-[#1a56ff] bg-[#1a56ff]/5' : 'border-slate-200 hover:border-[#1a56ff]/30'
              }`}
              onClick={() => toggle(addon.id)}
            >
              <div className="flex items-start gap-3">
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${
                  checked ? 'bg-[#1a56ff] text-white' : 'bg-slate-100 text-slate-500'
                }`}>
                  {addon.icon}
                </div>
                <div>
                  <p className="text-sm font-semibold text-slate-900">{t.order.addOns[addon.id]?.name ?? addon.name}</p>
                  <p className="text-xs text-slate-500">{t.order.addOns[addon.id]?.description ?? addon.description}</p>
                </div>
              </div>
              <div className="flex items-center gap-3 flex-shrink-0 ml-3">
                <span className="text-sm font-bold text-slate-900">${addon.price}</span>
                <div className={`w-5 h-5 rounded border-2 flex items-center justify-center transition-all ${
                  checked ? 'border-[#1a56ff] bg-[#1a56ff]' : 'border-slate-300'
                }`}>
                  {checked && <Check size={11} className="text-white" />}
                </div>
              </div>
            </label>
          )
        })}
      </div>
    </div>
  )
}

/* ── Step 5 — Account ────────────────────────────────────────────────── */
function StepAccount({ user, register, errors }: {
  user: { id: string; email?: string; displayName?: string } | null
  register: ReturnType<typeof useForm<WizardData>>['register']
  errors: ReturnType<typeof useForm<WizardData>>['formState']['errors']
}) {
  const { t } = useLang()
  if (user) {
    return (
      <div>
        <h2 className="text-2xl font-bold text-slate-900 mb-1">{t.order.yourAccountTitle}</h2>
        <p className="text-slate-500 text-sm mb-6">{t.order.signedInDesc}</p>
        <div className="bg-green-50 border border-green-200 rounded-xl p-4 flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-green-500 flex items-center justify-center text-white font-bold text-sm flex-shrink-0">
            {(user.displayName ?? user.email ?? 'U')[0].toUpperCase()}
          </div>
          <div>
            <p className="text-sm font-semibold text-slate-900">{user.displayName || user.email}</p>
            <p className="text-xs text-slate-500">{user.email}</p>
          </div>
          <Check size={16} className="text-green-500 ml-auto" />
        </div>
      </div>
    )
  }

  return (
    <div>
      <h2 className="text-2xl font-bold text-slate-900 mb-1">{t.order.createAccountTitle}</h2>
      <p className="text-slate-500 text-sm mb-6">{t.order.createAccountDesc}</p>

      <div className="space-y-4">
        <button
          type="button"
          onClick={() => supabase.auth.signInWithOAuth({ provider: 'google', options: { redirectTo: window.location.href } })}
          className="w-full flex items-center justify-center gap-3 border border-slate-300 rounded-xl py-3 text-sm font-semibold text-slate-700 hover:border-[#1a56ff] hover:text-[#1a56ff] transition-all"
        >
          <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
            <path d="M17.64 9.2c0-.637-.057-1.251-.164-1.84H9v3.481h4.844a4.14 4.14 0 01-1.796 2.716v2.259h2.908c1.702-1.567 2.684-3.875 2.684-6.616z" fill="#4285F4"/>
            <path d="M9 18c2.43 0 4.467-.806 5.956-2.18l-2.908-2.259c-.806.54-1.837.86-3.048.86-2.344 0-4.328-1.584-5.036-3.711H.957v2.332A8.997 8.997 0 009 18z" fill="#34A853"/>
            <path d="M3.964 10.71A5.41 5.41 0 013.682 9c0-.593.102-1.17.282-1.71V4.958H.957A8.996 8.996 0 000 9c0 1.452.348 2.827.957 4.042l3.007-2.332z" fill="#FBBC05"/>
            <path d="M9 3.58c1.321 0 2.508.454 3.44 1.345l2.582-2.58C13.463.891 11.426 0 9 0A8.997 8.997 0 00.957 4.958L3.964 6.29C4.672 4.163 6.656 3.58 9 3.58z" fill="#EA4335"/>
          </svg>
          {t.order.continueWithGoogle}
        </button>

        <div className="relative flex items-center gap-3">
          <div className="flex-1 h-px bg-slate-200" />
          <span className="text-xs text-slate-400 flex-shrink-0">{t.order.orFillDetails}</span>
          <div className="flex-1 h-px bg-slate-200" />
        </div>

        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-1.5">{t.order.fullNameLabel} <span className="text-red-500">*</span></label>
          <input
            {...register('fullName', { required: t.order.fullNameRequired })}
            placeholder={t.order.accountFullNamePlaceholder}
            className="w-full border border-slate-300 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-[#1a56ff] focus:ring-2 focus:ring-[#1a56ff]/10"
          />
          {errors.fullName && <p className="text-red-500 text-xs mt-1">{errors.fullName.message}</p>}
        </div>
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-1.5">{t.order.emailAddressLabel} <span className="text-red-500">*</span></label>
          <input
            {...register('email', {
              required: t.order.emailRequired,
              pattern: { value: /^\S+@\S+\.\S+$/, message: t.order.validEmail }
            })}
            type="email"
            placeholder={t.order.emailAddressPlaceholder}
            className="w-full border border-slate-300 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-[#1a56ff] focus:ring-2 focus:ring-[#1a56ff]/10"
          />
          {errors.email && <p className="text-red-500 text-xs mt-1">{errors.email.message}</p>}
        </div>
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-1.5">{t.order.whatsappLabel}</label>
          <input
            {...register('whatsapp')}
            placeholder={t.order.phonePlaceholder}
            className="w-full border border-slate-300 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-[#1a56ff] focus:ring-2 focus:ring-[#1a56ff]/10"
          />
          <p className="text-xs text-slate-400 mt-1">{t.order.whatsappNote}</p>
        </div>

        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4">
          <p className="text-amber-800 text-sm font-semibold mb-1">🔐 {t.order.accountCreatedTitle}</p>
          <p className="text-amber-700 text-xs">{t.order.accountCreatedDesc}</p>
        </div>
      </div>
    </div>
  )
}

/* ── Step 6 — Review & Pay ───────────────────────────────────────────── */
function StepReviewPay({
  data, plan, stateFee, selectedAddOns, members
}: {
  data: Partial<WizardData>
  plan: Plan | undefined
  stateFee: number
  selectedAddOns: AddOn[]
  members: Member[]
}) {
  const { t } = useLang()
  const addOnTotal = selectedAddOns.reduce((s, a) => s + a.price, 0)
  const total = (plan?.price || 0) + stateFee + addOnTotal

  return (
    <div>
      <h2 className="text-2xl font-bold text-slate-900 mb-1">{t.order.reviewPayTitle}</h2>
      <p className="text-slate-500 text-sm mb-6">{t.order.reviewPayDesc}</p>

      <div className="space-y-4">
        {/* Plan */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5">
          <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">{t.order.formationPackage}</p>
          <div className="flex items-center justify-between">
            <div>
              <p className="font-bold text-slate-900">{plan?.flag} {plan ? (t.order.plans[plan.id]?.name ?? plan.name) : ''}</p>
              <p className="text-sm text-slate-500">{plan ? (t.order.plans[plan.id]?.description ?? plan.description) : ''}</p>
            </div>
            <p className="text-2xl font-extrabold text-[#1a56ff]">${plan?.price}</p>
          </div>
        </div>

        {/* Company */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5">
          <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">{t.order.companyDetails}</p>
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div><p className="text-slate-500">{t.order.companyNameReview}</p><p className="font-semibold text-slate-900">{data.companyName || '—'} {data.companyType}</p></div>
            {data.companyState && <div><p className="text-slate-500">{t.order.stateReview}</p><p className="font-semibold text-slate-900">{data.companyState}</p></div>}
            <div><p className="text-slate-500">{t.order.entityReview}</p><p className="font-semibold text-slate-900">{data.companyType}</p></div>
          </div>
        </div>

        {/* Members */}
        {members.length > 0 && (
          <div className="bg-white border border-slate-200 rounded-2xl p-5">
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">{t.order.membersOwners}</p>
            <div className="space-y-2">
              {members.map((m, i) => (
                <div key={i} className="flex items-center justify-between text-sm">
                  <div>
                    <p className="font-semibold text-slate-900">{m.fullName || '—'}</p>
                    <p className="text-xs text-slate-500 capitalize">{m.role.replace('_', ' ')} · {m.email}</p>
                  </div>
                  <p className="font-bold text-slate-700">{m.ownership}%</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Add-ons */}
        {selectedAddOns.length > 0 && (
          <div className="bg-white border border-slate-200 rounded-2xl p-5">
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">{t.order.addOnServicesReview}</p>
            {selectedAddOns.map(a => (
              <div key={a.id} className="flex justify-between text-sm py-1">
                <span className="text-slate-700">{t.order.addOns[a.id]?.name ?? a.name}</span>
                <span className="font-semibold">${a.price}</span>
              </div>
            ))}
          </div>
        )}

        {/* Total */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5">
          <div className="space-y-2 text-sm">
            <div className="flex justify-between"><span className="text-slate-500">{t.order.basePackage}</span><span>${plan?.price}</span></div>
            {stateFee > 0 && <div className="flex justify-between"><span className="text-slate-500">{t.order.stateFeeLabel}</span><span>${stateFee}</span></div>}
            {addOnTotal > 0 && <div className="flex justify-between"><span className="text-slate-500">{t.order.addOnsTotal}</span><span>${addOnTotal}</span></div>}
          </div>
          <div className="border-t border-slate-100 mt-3 pt-3 flex justify-between items-center">
            <span className="font-bold text-slate-900">{t.order.total}</span>
            <span className="text-2xl font-extrabold text-[#1a56ff]">${total}</span>
          </div>
        </div>

        {/* Payment note */}
        <div className="bg-[#0a0f1e] rounded-2xl p-5 text-white">
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 bg-[#1a56ff] rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5">
              <Globe size={16} />
            </div>
            <div>
              <p className="font-semibold mb-1">{t.order.paymentViaInvoice}</p>
              <p className="text-white/60 text-sm">{t.order.paymentNote}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

/* ── Main wizard ─────────────────────────────────────────────────────────── */
export default function OrderWizard() {
  const navigate = useNavigate()
  const { user, isLoading: authLoading } = useAuth()

  const search = useSearch({ strict: false }) as { plan?: string }
  const preselect = search?.plan ?? 'us-premium'

  const [step, setStep] = useState(0)
  const [planId, setPlanId] = useState(preselect)
  const [stateFee, setStateFee] = useState(0)
  const [selectedAddOns, setSelectedAddOns] = useState<string[]>([])
  const [submitting, setSubmitting] = useState(false)
  const [members, setMembers] = useState<Member[]>([{
    id: crypto.randomUUID(),
    fullName: '',
    role: 'managing_member',
    ownership: 100,
    address: '',
    email: '',
    phone: ''
  }])

  const { t, isRTL, toggleLang, lang } = useLang()

  const { register, handleSubmit, getValues, trigger, setValue, formState: { errors } } = useForm<WizardData>({
    defaultValues: {
      planId: preselect,
      companyType: preselect.startsWith('uk') ? 'LTD' : 'LLC',
      email: user?.email ?? '',
      fullName: user?.displayName ?? '',
    }
  })

  // keep companyType in sync with planId
  const handleSetPlanId = (id: string) => {
    setPlanId(id)
    setValue('companyType', id.startsWith('uk') ? 'LTD' : 'LLC')
  }

  const plan = PLANS.find(p => p.id === planId)
  const addOnObjects = ADD_ONS.filter(a => selectedAddOns.includes(a.id))

  const TOTAL_STEPS = 6

  const next = async () => {
    let valid = true
    if (step === 0) valid = await trigger(['companyName'])
    if (step === 4) valid = await trigger(['fullName', 'email'])
    if (valid) setStep(s => Math.min(s + 1, TOTAL_STEPS - 1))
  }

  const back = () => setStep(s => Math.max(s - 1, 0))

  const onSubmit = async () => {
    setSubmitting(true)
    try {
      const data = getValues()
      const selectedPlan = PLANS.find(p => p.id === planId)!

      let uid = user?.id

      if (!uid) {
        const tempPassword = Math.random().toString(36).slice(2) + 'Aa1!'
        const { error: signUpErr } = await supabase.auth.signUp({
          email: data.email,
          password: tempPassword,
          options: { data: { full_name: data.fullName } },
        })
        if (signUpErr) throw signUpErr
        const { data: { user: newUser }, error: signInErr } = await supabase.auth.signInWithPassword({
          email: data.email,
          password: tempPassword,
        })
        if (signInErr) throw signInErr
        uid = newUser?.id
      }

      if (!uid) throw new Error('Authentication failed')

      const orderNumber = `IG-${Date.now().toString(36).toUpperCase()}`
      const addOnTotal = addOnObjects.reduce((s, a) => s + a.price, 0)
      const totalAmount = selectedPlan.price + stateFee + addOnTotal

      const { error: orderErr } = await supabase.from('orders').insert({
        user_id: uid,
        order_number: orderNumber,
        package_name: selectedPlan.name,
        company_name: data.companyName,
        company_state: data.companyState ?? 'N/A',
        company_type: data.companyType ?? (planId.startsWith('uk') ? 'LTD' : 'LLC'),
        status: 'pending',
        amount: totalAmount,
        currency: selectedPlan.currency,
        notes: [
          data.whatsapp ? `WhatsApp: ${data.whatsapp}` : '',
          selectedAddOns.length ? `Add-ons: ${selectedAddOns.join(', ')}` : '',
          members.length ? `Members: ${members.map(m => `${m.fullName} (${m.ownership}%)`).join(', ')}` : ''
        ].filter(Boolean).join(' | '),
      })
      if (orderErr) throw orderErr

      // Send order confirmation emails (fire and forget - don't block navigation)
      sendOrderConfirmationEmail({
        toEmail: data.email,
        toName: data.fullName,
        orderNumber,
        companyName: data.companyName,
        packageName: selectedPlan.name,
        amount: totalAmount,
        currency: selectedPlan.currency,
      }).catch(console.error)

      navigate({ to: '/order/success', search: { orderNumber, plan: selectedPlan.name, company: data.companyName } })
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to place order. Please try again.'
      toast.error(msg)
    } finally {
      setSubmitting(false)
    }
  }

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#1a56ff]" />
      </div>
    )
  }

  const formValues = getValues()

  return (
    <div className="force-light min-h-screen bg-slate-50" style={{ fontFamily: 'Sora, Inter, sans-serif' }}>
      {/* Top bar */}
      <header className="bg-white border-b border-slate-200 px-4 py-3 flex items-center justify-between">
        <a href="/" className="flex items-center gap-2">
          <img src="/logo.png" alt="Instant Grow" className="h-9 w-auto" />
        </a>
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={toggleLang}
            className="flex items-center gap-1.5 text-xs text-slate-600 hover:text-[#1a56ff] font-semibold transition-colors px-2 py-1 border border-slate-200 rounded-lg"
          >
            <Globe size={13} />
            {lang === 'en' ? 'العربية' : 'English'}
          </button>
          <span className="text-xs text-slate-400 hidden sm:block">🔒 {t.order.secureOrder}</span>
          {!user && (
            <a href="/auth/login" className="text-xs text-[#1a56ff] font-semibold hover:underline">{t.order.alreadyHaveAccount}</a>
          )}
        </div>
      </header>

      <div className="max-w-5xl mx-auto px-4 py-8">
        {/* Hero */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-1">{t.order.formYourBusiness}</h1>
          <p className="text-slate-500 text-sm">{t.order.completeSteps}</p>
        </div>

        <StepIndicator current={step} />

        <div className="flex flex-col lg:flex-row gap-6">
          {/* Main form */}
          <div className="flex-1">
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 sm:p-8">
              {step === 0 && (
                <StepCompanyInfo
                  register={register}
                  errors={errors}
                  planId={planId}
                  setPlanId={handleSetPlanId}
                  onStateFeeChange={setStateFee}
                />
              )}
              {step === 1 && (
                <StepMemberInfo members={members} setMembers={setMembers} />
              )}
              {step === 2 && (
                <StepServicePackage planId={planId} setPlanId={handleSetPlanId} />
              )}
              {step === 3 && (
                <StepAddOns selectedAddOns={selectedAddOns} setSelectedAddOns={setSelectedAddOns} />
              )}
              {step === 4 && (
                <StepAccount user={user} register={register} errors={errors} />
              )}
              {step === 5 && (
                <StepReviewPay
                  data={{ ...formValues, planId }}
                  plan={plan}
                  stateFee={stateFee}
                  selectedAddOns={addOnObjects}
                  members={members}
                />
              )}

              {/* Navigation */}
              <div className="flex items-center justify-between mt-8 pt-6 border-t border-slate-100">
                {step > 0 ? (
                  <button
                    type="button"
                    onClick={back}
                    className="flex items-center gap-2 text-sm font-semibold text-slate-600 hover:text-slate-900 transition-colors px-4 py-2.5 border border-slate-200 rounded-xl hover:border-slate-300"
                  >
                    {isRTL ? <ArrowRight size={15} /> : <ArrowLeft size={15} />} {t.order.previous}
                  </button>
                ) : (
                  <a href="/#pricing" className="flex items-center gap-2 text-sm font-semibold text-slate-600 hover:text-slate-900 px-4 py-2.5 border border-slate-200 rounded-xl">
                    {isRTL ? <ArrowRight size={15} /> : <ArrowLeft size={15} />} {t.order.backToPricing}
                  </a>
                )}

                {step < TOTAL_STEPS - 1 ? (
                  <button
                    type="button"
                    onClick={next}
                    className="flex items-center gap-2 bg-[#1a56ff] text-white font-semibold text-sm px-6 py-3 rounded-xl hover:bg-[#3a76ff] transition-colors shadow-sm"
                  >
                    {t.order.nextStep} {isRTL ? <ChevronLeft size={15} /> : <ChevronRight size={15} />}
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={onSubmit}
                    disabled={submitting}
                    className="flex items-center gap-2 bg-[#1a56ff] text-white font-semibold text-sm px-8 py-3 rounded-xl hover:bg-[#3a76ff] transition-colors disabled:opacity-60 shadow-sm"
                  >
                    {submitting ? (
                      <><span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> {t.order.placingOrder}</>
                    ) : (
                      <>{t.order.placeOrder} <Check size={15} /></>
                    )}
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Order summary sidebar */}
          <div className="lg:w-72">
            <OrderSummary
              plan={plan}
              stateFee={stateFee}
              addOns={selectedAddOns}
              selectedAddOns={addOnObjects}
            />
          </div>
        </div>
      </div>
    </div>
  )
}
