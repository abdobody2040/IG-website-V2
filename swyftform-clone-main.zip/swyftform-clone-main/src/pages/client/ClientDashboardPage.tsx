import { ArrowRight, ShoppingBag, Building2, FileText, Zap, CheckCircle, Clock, AlertCircle, CreditCard, Mail, ShieldCheck } from 'lucide-react'
import { Link } from '@tanstack/react-router'
import ClientLayout from './ClientLayout'
import { useRequireAuth } from '../../hooks/useRequireAuth'
import { useOrders } from '../../hooks/useOrders'
import { useCompanies } from '../../hooks/useCompanies'
import { useDocuments } from '../../hooks/useDocuments'
import type { Order } from '../../types/db'

// ─── Status config ─────────────────────────────────────────────────────────────

const STEP_ORDER: Record<string, number> = {
  pending: 0, in_review: 0, processing: 1,
  documents_filed: 2, ein_processing: 3, completed: 4, cancelled: -1,
}

const MAX_STEPS = 4

// ─── Circular Progress ─────────────────────────────────────────────────────────

function CircularProgress({ pct, status }: { pct: number; status: string }) {
  const r = 56
  const circ = 2 * Math.PI * r
  const offset = circ - (pct / 100) * circ
  const isCancelled = status === 'cancelled'
  const isComplete = status === 'completed'

  return (
    <div className="relative w-40 h-40 flex-shrink-0">
      <svg className="w-full h-full -rotate-90" viewBox="0 0 136 136">
        <circle cx="68" cy="68" r={r} fill="none" stroke="#e2e8f0" strokeWidth="10" />
        <circle
          cx="68" cy="68" r={r} fill="none"
          stroke={isCancelled ? '#ef4444' : isComplete ? '#22c55e' : '#1a56ff'}
          strokeWidth="10"
          strokeDasharray={circ}
          strokeDashoffset={offset}
          strokeLinecap="round"
          className="transition-all duration-700"
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-2xl font-bold text-slate-900">{pct}%</span>
        <span className="text-xs text-slate-500 mt-0.5">Complete</span>
      </div>
    </div>
  )
}

// ─── Payment Required Banner ───────────────────────────────────────────────────

function PaymentBanner({ order }: { order: Order }) {
  const isPending = order.status === 'pending'
  if (!isPending) return null
  return (
    <div className="bg-amber-50 border border-amber-200 rounded-xl p-5 mb-6 flex items-start gap-4">
      <div className="w-10 h-10 bg-amber-100 rounded-xl flex items-center justify-center flex-shrink-0">
        <AlertCircle size={20} className="text-amber-600" />
      </div>
      <div className="flex-1 min-w-0">
        <h4 className="font-semibold text-amber-900 text-sm">Payment Required</h4>
        <p className="text-amber-700 text-xs mt-0.5">Complete your payment to start the LLC formation process.</p>
      </div>
      <a
        href="/order"
        className="flex-shrink-0 flex items-center gap-1.5 bg-amber-500 text-white text-xs font-semibold px-4 py-2 rounded-lg hover:bg-amber-600 transition-colors"
      >
        <CreditCard size={13} />
        Complete Payment · ${order.amount.toLocaleString()}
      </a>
    </div>
  )
}

// ─── Formation Progress Card ───────────────────────────────────────────────────

function FormationProgressCard({ order, loading }: { order: Order | undefined; loading: boolean }) {
  const stepIdx = order ? (STEP_ORDER[order.status] ?? 0) : 0
  const pct = order?.status === 'cancelled' ? 0 : Math.round((stepIdx / MAX_STEPS) * 100)

  const STEPS = [
    { key: 'pending',          label: 'Order Received' },
    { key: 'processing',       label: 'Filing' },
    { key: 'documents_filed',  label: 'Docs Filed' },
    { key: 'ein_processing',   label: 'EIN' },
    { key: 'completed',        label: 'Complete' },
  ]

  const STEP_IDX_MAP: Record<string, number> = {
    pending: 0, in_review: 0, processing: 1,
    documents_filed: 2, ein_processing: 3, completed: 4,
  }

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
      <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100">
        <div className="flex items-center gap-2">
          <FileText size={15} className="text-[#1a56ff]" />
          <h3 className="font-semibold text-slate-900 text-sm">Formation Progress</h3>
        </div>
        <span className="text-xs text-slate-400">{order ? `LLC filing status` : 'No active order'}</span>
      </div>

      <div className="p-5">
        {loading ? (
          <div className="flex items-center justify-center py-8">
            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-[#1a56ff]" />
          </div>
        ) : order ? (
          <div className="flex items-center gap-8">
            <CircularProgress pct={pct} status={order.status} />
            <div className="flex-1 space-y-3">
              {STEPS.map((step, idx) => {
                const stepI = STEP_IDX_MAP[step.key] ?? idx
                const done = stepIdx >= stepI
                return (
                  <div key={step.key} className="flex items-center gap-2.5">
                    <div className={`w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 border-2 transition-all ${
                      done ? 'bg-[#1a56ff] border-[#1a56ff]' : 'border-slate-200 bg-white'
                    }`}>
                      {done && <CheckCircle size={12} className="text-white" strokeWidth={2.5} />}
                    </div>
                    <span className={`text-sm font-medium transition-colors ${done ? 'text-slate-900' : 'text-slate-400'}`}>
                      {step.label}
                    </span>
                  </div>
                )
              })}
            </div>
          </div>
        ) : (
          <div className="text-center py-6">
            <ShoppingBag size={32} className="text-slate-300 mx-auto mb-3" />
            <p className="text-sm text-slate-500 mb-4">No active formation</p>
            <a href="/order" className="inline-flex items-center gap-2 bg-[#1a56ff] text-white text-sm font-semibold px-4 py-2 rounded-lg hover:bg-[#1548d9] transition-colors">
              Start LLC Formation
            </a>
          </div>
        )}
      </div>
    </div>
  )
}

// ─── Company Info Card ────────────────────────────────────────────────────────

function CompanyInfoCard({ order, loading }: { order: Order | undefined; loading: boolean }) {
  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
      <div className="flex items-center gap-2 px-5 py-4 border-b border-slate-100">
        <Building2 size={15} className="text-green-600" />
        <h3 className="font-semibold text-slate-900 text-sm">Company Information</h3>
      </div>
      <div className="p-5">
        {loading ? (
          <div className="space-y-3">
            {[1,2,3].map(i => <div key={i} className="h-10 bg-slate-100 rounded-lg animate-pulse" />)}
          </div>
        ) : order ? (
          <div className="space-y-4">
            <div>
              <p className="text-xs text-slate-400 mb-0.5">Company Name</p>
              <p className="text-sm font-semibold text-slate-900">{order.companyName}</p>
            </div>
            <div>
              <p className="text-xs text-slate-400 mb-0.5">Formation State</p>
              <p className="text-sm font-semibold text-[#1a56ff]">{order.companyState}</p>
            </div>
            <div>
              <p className="text-xs text-slate-400 mb-0.5">Status</p>
              <p className="text-sm font-semibold text-slate-700 capitalize">{order.status?.replace(/_/g, ' ')}</p>
            </div>
            <div>
              <p className="text-xs text-slate-400 mb-0.5">Package</p>
              <p className="text-sm font-semibold text-slate-700">{order.packageName}</p>
            </div>
          </div>
        ) : (
          <div className="text-center py-4">
            <p className="text-sm text-slate-400">No company information yet.</p>
            <Link to="/client/orders" className="text-xs text-[#1a56ff] mt-2 inline-block hover:underline">View Orders</Link>
          </div>
        )}
      </div>
    </div>
  )
}

// ─── Main page ─────────────────────────────────────────────────────────────────

export default function ClientDashboardPage() {
  const { user, isLoading: authLoading } = useRequireAuth()
  const { orders, isLoading: ordersLoading } = useOrders(user?.id)
  const { companies } = useCompanies(user?.id)
  const { documents } = useDocuments(user?.id)

  if (authLoading) {
    return (
      <div className="flex items-center justify-center h-screen bg-slate-50">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#1a56ff]" />
      </div>
    )
  }

  const displayName = user?.displayName || user?.email?.split('@')[0] || 'there'
  const latestOrder = orders[0]
  const stepIdx = latestOrder ? (STEP_ORDER[latestOrder.status] ?? 0) : 0
  const pct = latestOrder?.status === 'cancelled' ? 0 : latestOrder?.status === 'completed' ? 100 : Math.round((stepIdx / MAX_STEPS) * 100)

  return (
    <ClientLayout currentPath="/client/dashboard" title="Dashboard">

      {/* Header */}
      <div className="mb-6">
        <h2 className="text-xl font-bold text-slate-900">Dashboard Overview</h2>
        <p className="text-slate-500 text-sm mt-0.5">
          {latestOrder
            ? `Your LLC formation is in progress.`
            : `Welcome back, ${displayName}. Start your LLC formation today.`}
        </p>
      </div>

      {/* Payment Banner */}
      {latestOrder && <PaymentBanner order={latestOrder} />}

      {/* Formation Progress + Company Info */}
      <div className="grid lg:grid-cols-3 gap-6 mb-6">
        <div className="lg:col-span-2">
          <FormationProgressCard order={latestOrder} loading={ordersLoading} />
        </div>
        <div>
          <CompanyInfoCard order={latestOrder} loading={ordersLoading} />
        </div>
      </div>

      {/* Quick Nav Grid */}
      <div>
        <h3 className="text-sm font-semibold text-slate-700 mb-3">Quick Access</h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {[
            { label: 'Payments',      href: '/client/payments',      icon: CreditCard,   color: 'text-green-600',  bg: 'bg-green-50' },
            { label: 'My Company',    href: '/client/company',       icon: Building2,    color: 'text-blue-600',   bg: 'bg-blue-50' },
            { label: 'Documents',     href: '/client/documents',     icon: FileText,     color: 'text-indigo-600', bg: 'bg-indigo-50' },
            { label: 'Mail Inbox',    href: '/client/mail-inbox',    icon: Mail,         color: 'text-orange-500', bg: 'bg-orange-50' },
            { label: 'Services',      href: '/client/services',      icon: Zap,          color: 'text-amber-600',  bg: 'bg-amber-50' },
            { label: 'Verifications', href: '/client/verifications', icon: ShieldCheck,  color: 'text-purple-600', bg: 'bg-purple-50' },
          ].map(action => {
            const Icon = action.icon
            return (
              <Link
                key={action.href}
                to={action.href}
                className="flex flex-col items-center gap-2 p-4 bg-white rounded-xl border border-slate-200 shadow-sm hover:shadow-md hover:border-[#1a56ff]/30 transition-all group text-center"
              >
                <div className={`w-10 h-10 ${action.bg} rounded-xl flex items-center justify-center`}>
                  <Icon size={18} className={action.color} />
                </div>
                <span className="text-xs font-semibold text-slate-700 group-hover:text-slate-900 leading-tight">{action.label}</span>
              </Link>
            )
          })}
        </div>
      </div>

    </ClientLayout>
  )
}
