import { Building2, MapPin, Hash, Calendar, User, CheckCircle, Clock, Phone, Mail, Home, Users, Plus } from 'lucide-react'
import { Link } from '@tanstack/react-router'
import ClientLayout from './ClientLayout'
import { useRequireAuth } from '../../hooks/useRequireAuth'
import { useCompanies } from '../../hooks/useCompanies'
import { useAuth } from '../../hooks/useAuth'
import type { Company } from '../../types/db'

// ─── Status config ────────────────────────────────────────────────────────────

const STATUS_CONFIG: Record<string, { label: string; color: string; bg: string; border: string }> = {
  pending:   { label: 'Pending',   color: 'text-amber-700',  bg: 'bg-amber-50',  border: 'border-amber-200' },
  active:    { label: 'Active',    color: 'text-green-700',  bg: 'bg-green-50',  border: 'border-green-200' },
  completed: { label: 'Active',    color: 'text-green-700',  bg: 'bg-green-50',  border: 'border-green-200' },
  cancelled: { label: 'Cancelled', color: 'text-red-700',    bg: 'bg-red-50',    border: 'border-red-200' },
}

// ─── Company Card ─────────────────────────────────────────────────────────────

function CompanyCard({ company, userEmail }: { company: Company; userEmail?: string }) {
  const statusCfg = STATUS_CONFIG[company.status] ?? STATUS_CONFIG.pending
  const formationFmt = company.formationDate
    ? new Date(company.formationDate).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })
    : 'March 29, 2026'

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden mb-5">
      {/* Status header bar */}
      <div className="grid grid-cols-4 border-b border-slate-100">
        {[
          { label: 'Service Status', value: <span className={`inline-flex items-center gap-1 text-xs font-semibold px-2 py-0.5 rounded-full border ${statusCfg.bg} ${statusCfg.border} ${statusCfg.color}`}>{statusCfg.label} <span className="text-slate-400 font-normal cursor-default">·</span></span> },
          { label: 'Formation Date', value: formationFmt },
          { label: 'EIN Number', value: company.einNumber || 'Pending' },
          { label: 'Entity Type', value: company.companyType || 'LLC' },
        ].map(item => (
          <div key={item.label} className="px-5 py-4 border-r border-slate-100 last:border-r-0">
            <p className="text-xs text-slate-400 mb-1">{item.label}</p>
            <div className="text-sm font-semibold text-slate-900">{item.value}</div>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 divide-x divide-slate-100">
        {/* Company Information */}
        <div className="lg:col-span-2 p-5">
          <h3 className="text-base font-semibold text-slate-900 mb-4 flex items-center gap-2">
            <Building2 size={16} className="text-[#1a56ff]" />
            Company Information
          </h3>

          <div className="grid grid-cols-2 gap-x-8 gap-y-4 mb-6">
            <div>
              <p className="text-xs text-slate-400 mb-0.5">Legal Name</p>
              <p className="text-sm font-semibold text-slate-900">{company.companyName}</p>
            </div>
            <div>
              <p className="text-xs text-slate-400 mb-0.5">Registration Number</p>
              <p className="text-sm font-semibold text-slate-900">{company.einNumber || 'Pending'}</p>
            </div>
            <div>
              <p className="text-xs text-slate-400 mb-0.5">State of Formation</p>
              <p className="text-sm font-semibold text-[#1a56ff]">{company.state || '—'}</p>
            </div>
            <div>
              <p className="text-xs text-slate-400 mb-0.5">Number of Members</p>
              <p className="text-sm font-semibold text-slate-900">1 Member</p>
            </div>
            <div className="col-span-2">
              <p className="text-xs text-slate-400 mb-0.5">Business Purpose</p>
              <p className="text-sm font-semibold text-slate-500">Not provided</p>
            </div>
          </div>

          {/* Members & Officers */}
          <div className="border-t border-slate-100 pt-4">
            <h4 className="text-sm font-semibold text-slate-800 mb-3 flex items-center gap-2">
              <Users size={14} className="text-slate-400" />
              Members &amp; Officers
            </h4>
            <div className="grid grid-cols-2 gap-x-8 gap-y-3">
              <div>
                <p className="text-xs text-slate-400 mb-0.5">Managing Member</p>
                <p className="text-sm font-semibold text-slate-900">{company.registeredAgent || 'Member'}</p>
              </div>
              <div>
                <p className="text-xs text-slate-400 mb-0.5">Ownership</p>
                <p className="text-sm font-semibold text-slate-900">100%</p>
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar — Contact + Address */}
        <div className="p-5 bg-slate-50/50">
          {/* Contact Information */}
          <div className="mb-5">
            <h4 className="text-sm font-semibold text-slate-800 mb-3">Contact Information</h4>
            <div className="space-y-3">
              <div className="flex items-start gap-2.5">
                <div className="w-6 h-6 rounded-md bg-white border border-slate-200 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <User size={11} className="text-slate-400" />
                </div>
                <div>
                  <p className="text-[10px] text-slate-400">Primary Contact</p>
                  <p className="text-sm font-semibold text-slate-900">{company.registeredAgent || 'Member'}</p>
                </div>
              </div>
              <div className="flex items-start gap-2.5">
                <div className="w-6 h-6 rounded-md bg-white border border-slate-200 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <Mail size={11} className="text-slate-400" />
                </div>
                <div className="flex items-start justify-between w-full gap-2">
                  <div>
                    <p className="text-[10px] text-slate-400">Email</p>
                    <p className="text-sm font-semibold text-slate-900 break-all">{userEmail ?? '—'}</p>
                  </div>
                </div>
              </div>
              <div className="flex items-start gap-2.5">
                <div className="w-6 h-6 rounded-md bg-white border border-slate-200 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <Phone size={11} className="text-slate-400" />
                </div>
                <div>
                  <p className="text-[10px] text-slate-400">Phone Number</p>
                  <p className="text-sm font-semibold text-slate-500">Not provided</p>
                </div>
              </div>
            </div>
          </div>

          {/* Address */}
          <div>
            <h4 className="text-sm font-semibold text-slate-800 mb-3">Address</h4>
            <div className="flex items-start gap-2.5">
              <div className="w-6 h-6 rounded-md bg-white border border-slate-200 flex items-center justify-center flex-shrink-0 mt-0.5">
                <Home size={11} className="text-slate-400" />
              </div>
              <div>
                <p className="text-[10px] text-slate-400">Principal Address</p>
                <p className="text-sm font-semibold text-slate-500">Not provided</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

// ─── Empty state ──────────────────────────────────────────────────────────────

function EmptyState() {
  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-12 text-center">
      <div className="w-16 h-16 bg-blue-50 rounded-2xl flex items-center justify-center mx-auto mb-4">
        <Building2 size={30} className="text-[#1a56ff]" />
      </div>
      <h3 className="font-semibold text-slate-900 mb-1">No company yet</h3>
      <p className="text-slate-500 text-sm max-w-sm mx-auto mb-6">
        Your company information will appear here after formation is complete.
      </p>
      <a
        href="/order"
        className="inline-flex items-center gap-2 bg-[#1a56ff] text-white text-sm font-semibold px-6 py-2.5 rounded-xl hover:bg-[#3a76ff] transition-colors"
      >
        Start LLC Formation
      </a>
    </div>
  )
}

// ─── Main page ────────────────────────────────────────────────────────────────

export default function ClientCompanyPage() {
  const { user, isLoading: authLoading } = useRequireAuth()
  const { companies, isLoading } = useCompanies(user?.id)
  const { user: authUser } = useAuth()

  if (authLoading) {
    return (
      <div className="flex items-center justify-center h-screen bg-slate-50">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#1a56ff]" />
      </div>
    )
  }

  return (
    <ClientLayout currentPath="/client/company" title="My Company">
      <div className="max-w-4xl">
        {/* Header */}
        <div className="mb-6 flex items-start justify-between gap-4">
          <div>
            <h2 className="text-xl font-bold text-slate-900">My Companies</h2>
            <p className="text-slate-500 text-sm mt-0.5">Manage your LLC / LTD company information and details.</p>
          </div>
          <Link
            to="/order"
            className="inline-flex items-center gap-2 bg-[#1a56ff] text-white text-sm font-semibold px-4 py-2 rounded-xl hover:bg-[#3a76ff] transition-colors flex-shrink-0"
          >
            <Plus size={15} />
            Add Company
          </Link>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <div className="animate-spin rounded-full h-7 w-7 border-b-2 border-[#1a56ff]" />
          </div>
        ) : companies.length === 0 ? (
          <EmptyState />
        ) : (
          companies.map(company => (
            <CompanyCard key={company.id} company={company} userEmail={authUser?.email} />
          ))
        )}
      </div>
    </ClientLayout>
  )
}
