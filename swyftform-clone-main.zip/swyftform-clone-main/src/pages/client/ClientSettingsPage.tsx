import { useState, useEffect } from 'react'
import { User, Bell, Shield, Trash2, Download, Loader2 } from 'lucide-react'
import ClientLayout from './ClientLayout'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../hooks/useAuth'
import toast from 'react-hot-toast'

interface NotifPrefs {
  emailNotifications: boolean
  documentUpdates: boolean
  paymentReminders: boolean
  marketingEmails: boolean
}

function Toggle({
  label,
  description,
  checked,
  onChange,
}: {
  label: string
  description: string
  checked: boolean
  onChange: (v: boolean) => void
}) {
  return (
    <div className="flex items-center justify-between gap-4">
      <div className="flex-1">
        <p className="text-sm font-medium text-slate-900">{label}</p>
        <p className="text-xs text-slate-500 mt-0.5">{description}</p>
      </div>
      <button
        type="button"
        onClick={() => onChange(!checked)}
        className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors duration-200 focus:outline-none flex-shrink-0 ${
          checked ? 'bg-[#1a56ff]' : 'bg-slate-200'
        }`}
      >
        <span className={`inline-block w-5 h-5 bg-white rounded-full shadow transition-transform duration-200 ${checked ? 'translate-x-5' : 'translate-x-0.5'}`} />
      </button>
    </div>
  )
}

export default function ClientSettingsPage() {
  const { user } = useAuth()
  const [saving, setSaving] = useState(false)
  const [displayName, setDisplayName] = useState('')
  const [phone, setPhone] = useState('')

  const [prefs, setPrefs] = useState<NotifPrefs>({
    emailNotifications: true,
    documentUpdates: true,
    paymentReminders: true,
    marketingEmails: false,
  })

  useEffect(() => {
    if (!user) return
    setDisplayName(user.displayName ?? '')
  }, [user])

  const handleSave = async () => {
    if (!user?.id) return
    setSaving(true)
    try {
      if (displayName && displayName !== user.displayName) {
        const { error: updateErr } = await supabase.from('profiles').update({ display_name: displayName }).eq('id', user.id)
        if (updateErr) throw updateErr
      }
      toast.success('Settings saved!')
    } catch {
      toast.error('Failed to save settings.')
    } finally {
      setSaving(false)
    }
  }

  return (
    <ClientLayout currentPath="/client/settings" title="Settings">
      <div className="max-w-4xl">
        {/* Header */}
        <div className="mb-6">
          <h2 className="text-xl font-bold text-slate-900">Settings</h2>
          <p className="text-slate-500 text-sm mt-0.5">Manage your account settings and preferences.</p>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Left column — Profile + Security */}
          <div className="lg:col-span-2 space-y-5">
            {/* Profile */}
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="flex items-center gap-2.5 px-5 py-4 border-b border-slate-100">
                <User size={15} className="text-[#1a56ff]" />
                <h3 className="text-base font-semibold text-slate-900">Profile Information</h3>
              </div>
              <div className="p-5 space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1.5">Full Name</label>
                  <input
                    type="text"
                    value={displayName}
                    onChange={e => setDisplayName(e.target.value)}
                    placeholder="Full Name"
                    className="w-full border border-slate-200 rounded-lg px-3 py-2.5 text-sm bg-white text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#1a56ff]/30 focus:border-[#1a56ff]"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1.5">Email Address</label>
                  <input
                    type="email"
                    value={user?.email ?? ''}
                    disabled
                    className="w-full border border-slate-200 rounded-lg px-3 py-2.5 text-sm bg-slate-50 text-slate-400 cursor-not-allowed"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1.5">Phone Number</label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={e => setPhone(e.target.value)}
                    placeholder="+1 (555) 123-4567"
                    className="w-full border border-slate-200 rounded-lg px-3 py-2.5 text-sm bg-white text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#1a56ff]/30 focus:border-[#1a56ff]"
                  />
                </div>
                <div className="flex justify-end pt-2">
                  <button
                    onClick={handleSave}
                    disabled={saving}
                    className="flex items-center gap-2 px-5 py-2.5 bg-[#1a56ff] text-white text-sm font-semibold rounded-xl hover:bg-[#3a76ff] transition-colors disabled:opacity-60"
                  >
                    {saving && <Loader2 size={14} className="animate-spin" />}
                    Save Changes
                  </button>
                </div>
              </div>
            </div>

            {/* Security */}
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="flex items-center gap-2.5 px-5 py-4 border-b border-slate-100">
                <Shield size={15} className="text-[#1a56ff]" />
                <h3 className="text-base font-semibold text-slate-900">Security</h3>
              </div>
              <div className="p-5">
                <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl border border-slate-100">
                  <div className="w-8 h-8 bg-white rounded-lg border border-slate-200 flex items-center justify-center flex-shrink-0">
                    <span className="text-base">🔑</span>
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-slate-900">Email / Password</p>
                    <p className="text-xs text-slate-500">Your password is managed through your account.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right column — Notifications + Privacy */}
          <div className="space-y-5">
            {/* Notifications */}
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="flex items-center gap-2.5 px-5 py-4 border-b border-slate-100">
                <Bell size={15} className="text-[#1a56ff]" />
                <h3 className="text-base font-semibold text-slate-900">Notifications</h3>
              </div>
              <div className="p-5 space-y-5">
                <Toggle
                  label="Email Notifications"
                  description="Receive email updates"
                  checked={prefs.emailNotifications}
                  onChange={v => setPrefs(p => ({ ...p, emailNotifications: v }))}
                />
                <Toggle
                  label="Document Updates"
                  description="Notify when documents are ready"
                  checked={prefs.documentUpdates}
                  onChange={v => setPrefs(p => ({ ...p, documentUpdates: v }))}
                />
                <Toggle
                  label="Payment Reminders"
                  description="Get payment due date reminders"
                  checked={prefs.paymentReminders}
                  onChange={v => setPrefs(p => ({ ...p, paymentReminders: v }))}
                />
                <Toggle
                  label="Marketing Emails"
                  description="Receive promotional content"
                  checked={prefs.marketingEmails}
                  onChange={v => setPrefs(p => ({ ...p, marketingEmails: v }))}
                />
              </div>
            </div>

            {/* Privacy */}
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="px-5 py-4 border-b border-slate-100">
                <h3 className="text-base font-semibold text-slate-900">Privacy</h3>
              </div>
              <div className="p-5 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-slate-900">Data Export</p>
                    <p className="text-xs text-slate-500">Download your account data</p>
                  </div>
                  <button className="flex items-center gap-1.5 text-xs font-semibold text-[#1a56ff] hover:underline">
                    <Download size={12} />
                    Export
                  </button>
                </div>
                <div className="pt-2 border-t border-slate-100">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-red-600">Delete Account</p>
                      <p className="text-xs text-slate-500">Permanently delete your account and all data</p>
                    </div>
                    <button className="flex items-center gap-1.5 text-xs font-semibold text-white bg-red-500 hover:bg-red-600 transition-colors px-3 py-1.5 rounded-lg">
                      <Trash2 size={11} />
                      Delete
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </ClientLayout>
  )
}
