import { useState } from 'react'
import {
  Calendar, RefreshCw, Hash, FileEdit, Award, ArrowRight,
  FileText, Loader2, CheckCircle, AlertCircle, X, ExternalLink,
  Mail, Building2, User, Phone,
} from 'lucide-react'
import ClientLayout from './ClientLayout'
import { useAuth } from '../../hooks/useAuth'
import { useCompanies } from '../../hooks/useCompanies'

// ── Service catalogue ───────────────────────────────────────────────────────
const ADDON_SERVICES = [
  {
    id: 'annual-report',
    icon: Calendar,
    title: 'Annual Report Filing',
    price: 149,
    period: 'per filing',
    description: 'Stay compliant and avoid penalties. We handle your annual state report filing on time, every time.',
    badge: 'Most Popular',
    detail: 'We prepare and file your LLC annual report with the state to keep your business in good standing and avoid late fees.',
    requiresCompany: true,
  },
  {
    id: 'registered-agent-renewal',
    icon: RefreshCw,
    title: 'Registered Agent Renewal',
    price: 99,
    period: 'per year',
    description: 'Keep your registered agent service active to ensure you never miss important legal notices.',
    badge: null,
    detail: 'Renews your registered agent subscription for another 12 months. We receive and forward all state and legal correspondence.',
    requiresCompany: false,
  },
  {
    id: 'ein-amendment',
    icon: Hash,
    title: 'EIN Amendment',
    price: 79,
    period: 'one-time',
    description: 'Need to update your EIN information? We file the amendment with the IRS quickly and accurately.',
    badge: null,
    detail: 'We file IRS Form SS-4 amendments to update the responsible party, address, or other EIN-related changes on your behalf.',
    requiresCompany: true,
  },
  {
    id: 'operating-agreement',
    icon: FileEdit,
    title: 'Operating Agreement Update',
    price: 49,
    period: 'per update',
    description: "Update your LLC's operating agreement to reflect ownership changes, new members, or policy updates.",
    badge: null,
    detail: 'Our legal team drafts a revised operating agreement reflecting your changes, signed and ready to use.',
    requiresCompany: false,
  },
  {
    id: 'good-standing',
    icon: Award,
    title: 'Certificate of Good Standing',
    price: 79,
    period: 'per request',
    description: 'Obtain an official Certificate of Good Standing from the state to prove your LLC is active and compliant.',
    badge: null,
    detail: 'We request an official certificate from the state on your behalf, typically delivered in 3–5 business days.',
    requiresCompany: true,
  },
]

type Service = typeof ADDON_SERVICES[0]

// ── Order Request Modal ─────────────────────────────────────────────────────
interface OrderModalProps {
  service: Service
  userEmail: string
  userName: string
  companies: Array<{ id: string; companyName: string; companyType: string; state: string }>
  onClose: () => void
}

function OrderModal({ service, userEmail, userName, companies, onClose }: OrderModalProps) {
  const Icon = service.icon
  const [form, setForm] = useState({
    name: userName || '',
    email: userEmail || '',
    phone: '',
    companyId: companies[0]?.id || '',
    notes: '',
  })
  const [submitting, setSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setSubmitting(true)

    const selectedCompany = companies.find(c => c.id === form.companyId)
    const companyInfo = selectedCompany
      ? `${selectedCompany.companyName} (${selectedCompany.companyType} · ${selectedCompany.state})`
      : 'N/A'

    const subject = encodeURIComponent(`Service Request: ${service.title} — $${service.price}`)
    const body = encodeURIComponent(
      `Hi Instant Grow team,\n\n` +
      `I'd like to order the following service:\n\n` +
      `Service: ${service.title}\n` +
      `Price: $${service.price} ${service.period}\n\n` +
      `My details:\n` +
      `Name: ${form.name}\n` +
      `Email: ${form.email}\n` +
      `Phone: ${form.phone || 'Not provided'}\n` +
      `Company: ${companyInfo}\n\n` +
      `Additional notes:\n${form.notes || 'None'}\n\n` +
      `Please reach out to confirm next steps.\n\nThank you.`
    )

    window.open(`mailto:info@instantgrow.net?subject=${subject}&body=${body}`, '_blank')

    // Small delay to feel responsive
    await new Promise(r => setTimeout(r, 600))
    setSubmitting(false)
    setSubmitted(true)
  }

  if (submitted) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
        <div className="bg-white rounded-2xl shadow-2xl max-w-sm w-full p-8 text-center relative">
          <button onClick={onClose} className="absolute top-4 right-4 text-slate-400 hover:text-slate-600">
            <X size={18} />
          </button>
          <div className="w-16 h-16 bg-green-50 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle size={32} className="text-green-500" />
          </div>
          <h3 className="text-lg font-bold text-slate-900 mb-2">Request Sent!</h3>
          <p className="text-sm text-slate-500 mb-6">
            Your email client opened with a pre-filled request for <strong>{service.title}</strong>.
            Our team will contact you within 1 business day.
          </p>
          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-[#1a56ff] text-white text-sm font-semibold hover:bg-[#1440d0] transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full relative">
        {/* Header */}
        <div className="flex items-center gap-3 p-6 border-b border-slate-100">
          <div className="w-10 h-10 rounded-xl bg-[#e8efff] text-[#1a56ff] flex items-center justify-center flex-shrink-0">
            <Icon size={20} />
          </div>
          <div className="flex-1">
            <h3 className="font-semibold text-slate-900">{service.title}</h3>
            <p className="text-xs text-slate-500">{service.detail}</p>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 ml-2">
            <X size={18} />
          </button>
        </div>

        {/* Price summary */}
        <div className="flex items-center justify-between px-6 py-3 bg-slate-50 border-b border-slate-100">
          <span className="text-sm text-slate-600">Service fee</span>
          <span className="text-lg font-bold text-slate-900">${service.price} <span className="text-sm font-normal text-slate-400">{service.period}</span></span>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Full Name *</label>
              <div className="relative">
                <User size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  required
                  value={form.name}
                  onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                  placeholder="John Doe"
                  className="w-full pl-8 pr-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1a56ff]/20 focus:border-[#1a56ff]"
                />
              </div>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Phone</label>
              <div className="relative">
                <Phone size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  value={form.phone}
                  onChange={e => setForm(f => ({ ...f, phone: e.target.value }))}
                  placeholder="+1 555 000 0000"
                  className="w-full pl-8 pr-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1a56ff]/20 focus:border-[#1a56ff]"
                />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Email *</label>
            <div className="relative">
              <Mail size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                required
                type="email"
                value={form.email}
                onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
                placeholder="you@example.com"
                className="w-full pl-8 pr-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1a56ff]/20 focus:border-[#1a56ff]"
              />
            </div>
          </div>

          {companies.length > 0 && (
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                {service.requiresCompany ? 'Company *' : 'Company (optional)'}
              </label>
              <div className="relative">
                <Building2 size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <select
                  required={service.requiresCompany}
                  value={form.companyId}
                  onChange={e => setForm(f => ({ ...f, companyId: e.target.value }))}
                  className="w-full pl-8 pr-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1a56ff]/20 focus:border-[#1a56ff] appearance-none bg-white"
                >
                  {!service.requiresCompany && <option value="">None</option>}
                  {companies.map(c => (
                    <option key={c.id} value={c.id}>
                      {c.companyName} ({c.companyType} · {c.state})
                    </option>
                  ))}
                </select>
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Additional Notes</label>
            <textarea
              value={form.notes}
              onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
              rows={3}
              placeholder="Any specific details or instructions for this service…"
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1a56ff]/20 focus:border-[#1a56ff] resize-none"
            />
          </div>

          <div className="flex gap-3 pt-1">
            <button
              type="button"
              onClick={onClose}
              disabled={submitting}
              className="flex-1 py-2.5 rounded-xl border border-slate-200 text-slate-700 text-sm font-semibold hover:bg-slate-50 transition-colors disabled:opacity-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="flex-1 py-2.5 rounded-xl bg-[#1a56ff] text-white text-sm font-semibold hover:bg-[#1440d0] transition-colors disabled:opacity-70 flex items-center justify-center gap-2"
            >
              {submitting ? (
                <><Loader2 size={14} className="animate-spin" /> Sending…</>
              ) : (
                <><Mail size={14} /> Send Request</>
              )}
            </button>
          </div>

          <p className="text-xs text-slate-400 text-center">
            This opens your email client with a pre-filled request. Our team will confirm and send an invoice.
          </p>
        </form>
      </div>
    </div>
  )
}

// ── Main page ───────────────────────────────────────────────────────────────
export default function ClientServicesPage() {
  const { user } = useAuth()
  const { companies } = useCompanies(user?.id)
  const [selected, setSelected] = useState<Service | null>(null)

  const companyList = (companies ?? []).map(c => ({
    id: c.id,
    companyName: c.companyName,
    companyType: c.companyType,
    state: c.state,
  }))

  return (
    <ClientLayout currentPath="/client/services" title="Services">
      <div className="max-w-5xl">
        {/* Header */}
        <div className="mb-6">
          <h2 className="text-xl font-bold text-slate-900">Add-On Services</h2>
          <p className="text-slate-500 text-sm mt-0.5">
            Keep your LLC compliant and up to date with our professional services.
          </p>
        </div>

        {/* Info banner */}
        <div className="bg-[#e8efff] border border-[#1a56ff]/20 rounded-2xl p-4 flex gap-3 items-center mb-8">
          <div className="w-8 h-8 rounded-lg bg-[#1a56ff] flex items-center justify-center flex-shrink-0">
            <Mail size={14} className="text-white" />
          </div>
          <p className="text-sm text-[#1a40b0]">
            Click <strong>"Order Service"</strong> to submit a request. Our team will review it and send you a payment link within 1 business day.
          </p>
        </div>

        {/* Service cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 mb-12">
          {ADDON_SERVICES.map(svc => {
            const Icon = svc.icon
            return (
              <div
                key={svc.id}
                className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 flex flex-col gap-4 hover:shadow-md hover:border-[#1a56ff]/20 transition-all duration-200 relative"
              >
                {svc.badge && (
                  <span className="absolute top-4 right-4 bg-[#1a56ff] text-white text-xs font-semibold px-2.5 py-0.5 rounded-full">
                    {svc.badge}
                  </span>
                )}
                <div className="w-12 h-12 rounded-xl bg-[#e8efff] text-[#1a56ff] flex items-center justify-center flex-shrink-0">
                  <Icon size={22} />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900 text-base">{svc.title}</h3>
                  <div className="flex items-baseline gap-1 mt-1 mb-3">
                    <span className="text-2xl font-bold text-[#1a56ff]">${svc.price}</span>
                    <span className="text-sm text-gray-400">{svc.period}</span>
                  </div>
                  <p className="text-sm text-gray-500 leading-relaxed">{svc.description}</p>
                </div>

                <button
                  onClick={() => setSelected(svc)}
                  className="flex items-center justify-center gap-2 w-full py-2.5 px-4 rounded-xl border-2 border-[#1a56ff] text-[#1a56ff] text-sm font-semibold hover:bg-[#1a56ff] hover:text-white transition-all duration-200"
                >
                  Order Service
                  <ArrowRight size={14} />
                </button>
              </div>
            )
          })}
        </div>

        {/* Coming Soon — ITIN only */}
        <div className="mb-6">
          <h2 className="text-xl font-bold text-slate-900">Coming Soon</h2>
          <p className="text-slate-500 text-sm mt-0.5">More services are on the way.</p>
        </div>

        <div className="max-w-xs">
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="flex justify-end px-4 pt-4">
              <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-slate-100 text-slate-500 border border-slate-200">
                Coming Soon
              </span>
            </div>
            <div className="px-5 pb-5 pt-2">
              <div className="w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center mb-4">
                <FileText size={22} className="text-[#1a56ff]" />
              </div>
              <h3 className="font-semibold text-slate-900 mb-2">ITIN Application</h3>
              <p className="text-sm text-slate-500 leading-relaxed mb-5">
                Get your Individual Taxpayer Identification Number (ITIN) for tax filing purposes
                if you don't qualify for an SSN.
              </p>
              <button
                disabled
                className="w-full py-2 rounded-lg bg-slate-100 text-slate-400 text-sm font-semibold cursor-not-allowed"
              >
                Coming Soon
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Order modal */}
      {selected && (
        <OrderModal
          service={selected}
          userEmail={user?.email ?? ''}
          userName={user?.displayName ?? ''}
          companies={companyList}
          onClose={() => setSelected(null)}
        />
      )}
    </ClientLayout>
  )
}
