import { Mail, MapPin, Calendar, ShieldCheck, AlertCircle } from 'lucide-react'
import ClientLayout from './ClientLayout'
import { useRequireAuth } from '../../hooks/useRequireAuth'
import { useCompanies } from '../../hooks/useCompanies'

export default function ClientMailInboxPage() {
  const { user, isLoading: authLoading } = useRequireAuth()
  const { companies, isLoading } = useCompanies(user?.id)

  if (authLoading) {
    return (
      <div className="flex items-center justify-center h-screen bg-slate-50">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#1a56ff]" />
      </div>
    )
  }

  const firstCompany = companies[0]

  return (
    <ClientLayout currentPath="/client/mail-inbox" title="Mail Inbox">
      <div className="max-w-3xl">
        {/* Header */}
        <div className="mb-6">
          <h2 className="text-xl font-bold text-slate-900">Mail Inbox</h2>
          <p className="text-slate-500 text-sm mt-0.5">View your scanned mail and registered agent status.</p>
        </div>

        {/* Registered Agent Card */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden mb-5">
          <div className="flex items-start justify-between p-5">
            <div className="flex items-start gap-4">
              <div className="w-11 h-11 rounded-xl bg-blue-50 flex items-center justify-center flex-shrink-0">
                <ShieldCheck size={20} className="text-[#1a56ff]" />
              </div>
              <div>
                <h3 className="font-semibold text-slate-900">Registered Agent</h3>
                <p className="text-sm text-slate-500 mt-0.5">
                  {isLoading ? '…' : firstCompany?.state ?? 'N/A'}
                </p>
              </div>
            </div>
            <span className="inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full border bg-green-50 border-green-200 text-green-700">
              Active
            </span>
          </div>
          <div className="border-t border-slate-100 px-5 py-3">
            <p className="text-sm text-slate-600">
              We provide a registered agent address in your state of formation to receive legal documents on behalf of your LLC.
            </p>
          </div>
          <div className="border-t border-slate-100 px-5 py-3 grid grid-cols-2 gap-4">
            <div>
              <p className="text-xs text-slate-400 mb-0.5">State</p>
              <div className="flex items-center gap-1.5 text-sm font-semibold text-slate-800">
                <MapPin size={13} className="text-slate-400" />
                {isLoading ? '—' : firstCompany?.state ?? 'Not set'}
              </div>
            </div>
            <div>
              <p className="text-xs text-slate-400 mb-0.5">Renewal Date</p>
              <div className="flex items-center gap-1.5 text-sm font-semibold text-slate-800">
                <Calendar size={13} className="text-slate-400" />
                Not set
              </div>
            </div>
          </div>
        </div>

        {/* Scanned Mail */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden mb-5">
          <div className="flex items-center gap-3 px-5 py-4 border-b border-slate-100">
            <div className="w-9 h-9 bg-orange-50 rounded-xl flex items-center justify-center">
              <Mail size={16} className="text-orange-500" />
            </div>
            <div>
              <h3 className="font-semibold text-slate-900">Scanned Mail</h3>
              <p className="text-sm text-slate-400">No mail received yet</p>
            </div>
          </div>

          {/* Empty state */}
          <div className="flex flex-col items-center justify-center py-16 text-center px-6">
            <div className="w-16 h-16 bg-slate-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Mail size={28} className="text-slate-300" />
            </div>
            <p className="text-sm font-medium text-slate-500 mb-1">No scanned mail yet</p>
            <p className="text-xs text-slate-400 max-w-xs">
              Mail sent to your registered agent address will appear here.
            </p>
          </div>
        </div>

        {/* Stay Compliant Banner */}
        <div className="bg-blue-50 border border-blue-100 rounded-xl p-5 flex items-start gap-3">
          <div className="w-8 h-8 bg-[#1a56ff]/10 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5">
            <AlertCircle size={16} className="text-[#1a56ff]" />
          </div>
          <div>
            <h4 className="text-sm font-semibold text-slate-900">Stay Compliant</h4>
            <p className="text-sm text-slate-600 mt-0.5">
              Keep your business in good standing by staying on top of renewals and filings. We'll send you reminders when action is needed.
            </p>
          </div>
        </div>
      </div>
    </ClientLayout>
  )
}
