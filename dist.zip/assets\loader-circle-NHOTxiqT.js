import{c}from"./vendor-zod-Bo2-69-5.js";const e=[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]],a=c("loader-circle",e);export{a as L};
