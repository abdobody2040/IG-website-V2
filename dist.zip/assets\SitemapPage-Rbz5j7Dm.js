import{r as d}from"./vendor-tanstack-ujJP3qAW.js";import{p as n}from"./index-D6NYJkYF.js";import"./vendor-icons-QWT5sPed.js";import"./vendor-framer-CRZpNWqo.js";import"./vendor-lenis-BEW9yqGz.js";const o=typeof window<"u"?window.location.origin:"https://www.instantgrow-llc.com";function g(s){return s.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function b(){return d.useEffect(()=>{let s=!1;return(async()=>{const[i,c]=await Promise.all([n.collection("blogs").getList(1,500,{filter:"published = true",fields:"slug,updated"}),n.collection("countries_seo_pages").getList(1,500,{filter:"published = true",fields:"slug,updated"})]);if(s)return;const l=[],t=(e,p,u,r)=>{const m=g(e);l.push(`  <url>
    <loc>${m}</loc>
    <priority>${p}</priority>
    <changefreq>${u}</changefreq>${r?`
    <lastmod>${r}</lastmod>`:""}
  </url>`)};t(`${o}/`,"1.0","weekly"),t(`${o}/blog`,"0.8","weekly"),t(`${o}/contact`,"0.6","monthly");for(const e of i.items||[])t(`${o}/blog/${e.slug}`,"0.7","monthly",e.updated?.split("T")[0]);for(const e of c.items||[])t(`${o}/us-company/${e.slug}`,"0.9","monthly",e.updated?.split("T")[0]);const a=`<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${l.join(`
`)}
</urlset>`;document.open(),document.write(a),document.close()})(),()=>{s=!0}},[]),null}export{b as default};
