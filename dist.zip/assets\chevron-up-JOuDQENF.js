import{c as o}from"./vendor-zod-Bo2-69-5.js";const c=[["path",{d:"m18 15-6-6-6 6",key:"153udz"}]],n=o("chevron-up",c);export{n as C};
